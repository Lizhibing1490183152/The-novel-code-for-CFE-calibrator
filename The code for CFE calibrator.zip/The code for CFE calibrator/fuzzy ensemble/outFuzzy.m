function kq=outFuzzy(va1,v1,va2,v2)
temp=va1*v1+va2*v2;
kq=temp;


