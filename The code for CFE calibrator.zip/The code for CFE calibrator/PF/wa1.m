a=-9;
b=norm(a);
