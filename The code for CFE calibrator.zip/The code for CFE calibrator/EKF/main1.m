%revision history:
%v1: Feb.5th, 2020,by Shuai Li
%v2: Feb. 11th,2020 by Shuai Li
clear all
close all
tic
%------------------------------------------
%�궨���֣��������ݼ����б궨
%�ⲿ���ǻ�������������pre_processing.m(����matlab���������ȡ���궨��е�۵�foward
%kinematics����Բ����㶯��Jacobian���󣩣�my_forward.m(��pre_processing.m��õ�forward
%kinematics����my_Jacobian.m����pre_processing.m��õ�Jacobian)��
%------------------------------------------
%ϵͳ������������е�۵���ʵ����ֵ���������ֵ��
%����˳��a1,a2,a3,a4,a5,a6,d1,d2,d3,d4,d5,d6,alpha1,alpha2,alpha3,alpha4,alpha5,alpha6,...
%theta0_1,theta0_2,theta0_3,theta0_4,theta0_5,theta0_6;
%a_d_alpha_theta0_ex=rand(24,1);%[];%�����˵���ʵ����a d alpha theta0
    a_d_alpha_theta0_norm0=...
    [0 0.27 0.07 0 0 0 ...
    0.29 0 0 0.302 0 0.072 ...
    -1.571 0 -1.571 1.571 -1.571 0 ...
    0 -1.57 0 0 0 0]';



%P0=[0.5,-1,1-0.0627]';%�궨��
 %P0=[0.242654051842270 -0.453838756463155 0.007685659149684]';
% P0=[ 0.242 -0.453 0.006]';%Ч����
 P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
%a_d_alpha_theta0_norm=rand(24,1);%[];%�����˵��������a d alpha theta0
a_d_alpha_theta0_norm=a_d_alpha_theta0_norm0;
%a_d_alpha_theta0_ex=a_d_alpha_theta0_norm.*(1+0.05*rands(24,1))+0.05*rands(24,1)+0.1*randn(24,1);
% a_d_alpha_theta0_ex=a_d_alpha_theta0_norm.*(1+0.05*rands(27,1))+0.05*rands(27,1);
%  a_d_alpha_theta0_ex=a_d_alpha_theta0_norm.*(1+0.05*rands(24,1))+0.05*rands(24,1);
%a_d_alpha_theta0_ex=a_d_alpha_theta0_norm0;
Data1 = xlsread('Data.xlsx',1,'D2:J112');
Data2 = xlsread('Data.xlsx',2,'D2:J22');
U=Data1(:,1:6)*pi/180;
MM1=Data1(:,7)/1000;
UU=Data2(:,1:6)*pi/180;
VV1=Data2(:,7)/1000;

%------------------------------------------
%robot configurations for experiments
% q1_batch = pi/2*rands(30,1);
% q2_batch = pi/2*rands(30,1);
% q3_batch = pi/2*rands(30,1);
% q4_batch = pi/2*rands(30,1);
% q5_batch = pi/2*rands(30,1);
% q6_batch = pi/2*rands(30,1);
q1_batch = U(:,1);
q2_batch = U(:,2);
q3_batch = U(:,3);
q4_batch = U(:,4);
q5_batch = U(:,5);
q6_batch = U(:,6);
% % P0=[1,-1,0.16-0.0627]';%�궨��
KH1=0.0004;
% 
% %------------------------------------------%------------------------------------------
% %------------------------------------------%------------------------------------------
%Iter=8;
Iter=5;
MSE_store=zeros(0,1);
%L_norm1_store=zeros(0,1);
  %L_ex11_store=zeros(0,1);
  Iter1=10;
  
%����̶���Ѱ��
% for iteration=1:Iter1
% %------------------------------------------
% %--------
% % delta0=0;
% % delta1=0;
% delta2=0;
% delta3=0;
% MSE=0;
% 
% %a_d_alpha_theta0_norm=a_d_alpha_theta0_norm+0.2*rands(24,1);
% %a_d_alpha_theta0_ex=a_d_alpha_theta0_ex+0.4*rands(24,1);
% %--------
% for i = 1:length(q1_batch)%each i represent one measurement
%     q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
%     L_ex11=MM1(i);
% %     L_ex11=my_forward(a_d_alpha_theta0_ex,q,P0);
%      L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
%     J_norm1=my_Jacobian(a_d_alpha_theta0_norm,q,P0);%�����ݶ�
%     J_norm2=my_Jacobian1(a_d_alpha_theta0_norm,q,P0);%�궨���ݶ�
%     Error1=L_norm1-L_ex11;
% %     MSE=MSE+(norm(Error1))^2;
%     MSE=MSE+(norm(Error1));
% %     delta0=delta0+J_norm1'*Error;
% %     delta1=delta1+J_norm1'*J_norm1;
%     delta2=delta2+J_norm2'*Error1;
%     delta3=delta3+J_norm2'*J_norm2;
%     %L_norm1_store=[L_norm1_store;L_norm1];
%     %L_ex11_store=[L_ex11_store;L_ex11];
%      %delta122=J_norm1'*Error;
% end
% % delta0=delta0/length(q1_batch);
% % delta1=delta1/length(q1_batch);
% MSE=MSE/length(q1_batch);
% delta2=delta2/length(q1_batch);
% delta3=delta3/length(q1_batch);
% MSE=MSE*1000;
% MSE_store=[MSE_store;MSE];
% % MSE=MSE/length(q1_batch);
% % MSE_store=[MSE_store;MSE];
% %a_d_alpha_theta0_ex=a_d_alpha_theta0_ex+0.4*rands(24,1);
% %%%-------------
% %Put your algorithm here
% %Method 1: gradient
% %a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-0.5*delta0;
% %%%-------------
% %Method 2: recursive least square
% %a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-inv(delta1+0.0004*eye(24))*delta0;
% 
% % a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-pinv(delta1+KH1*eye(24))*delta0;
% P0=P0-(pinv(delta3+KH1*eye(3))*delta2);
% %P0=P0-(pinv(delta3+KH1*eye(3))*delta2);
% 
% 
% %a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-pinv(delta1)*delta0-0.0004*eye(27)*delta122;
% 
% end 
% P1=P0;


% %%LM�㷨
% for iteration=1:Iter
% %------------------------------------------
% %--------
% delta0=0;
% delta1=0;
% % delta2=0;
% % delta3=0;
% MSE=0;
% 
% %a_d_alpha_theta0_norm=a_d_alpha_theta0_norm+0.2*rands(24,1);
% %a_d_alpha_theta0_ex=a_d_alpha_theta0_ex+0.4*rands(24,1);
% %--------
% for i = 1:length(q1_batch)%each i represent one measurement
%     q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
%     L_ex11=MM1(i);
% %     L_ex11=my_forward(a_d_alpha_theta0_ex,q,P0);
%      L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
%     J_norm1=my_Jacobian(a_d_alpha_theta0_norm,q,P0);%�����ݶ�
%     %J_norm2=my_Jacobian1(a_d_alpha_theta0_norm,q,P0);%�궨���ݶ�
%     Error=L_norm1-L_ex11;
%     %MSE=MSE+(norm(Error))^2;
%      MSE=MSE+(norm(Error));
%     delta0=delta0+J_norm1'*Error;
%     delta1=delta1+J_norm1'*J_norm1;
% %     delta2=delta2+J_norm2'*Error;
% %     delta3=delta3+J_norm2'*J_norm2;
%     %L_norm1_store=[L_norm1_store;L_norm1];
%     %L_ex11_store=[L_ex11_store;L_ex11];
%      %delta122=J_norm1'*Error;
% end
% delta0=delta0/length(q1_batch);
% delta1=delta1/length(q1_batch);
% % delta2=delta2/length(q1_batch);
% % delta3=delta3/length(q1_batch);
% MSE=MSE/length(q1_batch);
%  MSE=MSE*1000;
% MSE_store=[MSE_store;MSE];
% %a_d_alpha_theta0_ex=a_d_alpha_theta0_ex+0.4*rands(24,1);
% %%%-------------
% %Put your algorithm here
% %Method 1: gradient
% %a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-0.5*delta0;
% %%%-------------
% %Method 2: recursive least square
% %a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-inv(delta1+0.0004*eye(24))*delta0;
% 
%  a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-pinv(delta1+KH1*eye(24))*delta0;
% %a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-pinv(delta1)*delta0;
%   end


% % 
% %%��������LM
% % Iter=2;
%  %for iteration=1:Iter
% MSE_store=zeros(0,1);
% delta0=0;
% 
% N = length(q1_batch);
% K = zeros(24,24);
% X = a_d_alpha_theta0_norm;
% % P = 1e-5*eye(24);
% % Q=1e-6*eye(24);
% % R=1e-6*eye(3);
% % P = 2e-7*eye(24);
% % Q=2e-7*eye(24);
% % R=2e-7*eye(1);
% P = 4.5e-6*eye(24);
% Q=2e-9*eye(24);
% R=1e-5*eye(1);
% % P = 4.5e-6*rands(24,24);
% % Q=2e-9*rands(24,24);
% % R=1e-5*rands(1,1);
% I=eye(24);
% I1=eye(1);
% X=a_d_alpha_theta0_norm;
% Xkf=X;
% % P_pre=0;
% % Kg=zeros(24,1);
% %Iter1=2;
%   
%  
% for i = 1:N%each i represent one measurement
%     q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
% %     J_norm1=my_Jacobian(a_d_alpha_theta0_norm,q);
% %     J_norm2=my_Jacobian(a_d_alpha_theta0_ex,q);
%       L_ex11=MM1(i);
% %     L_ex11=my_forward(a_d_alpha_theta0_ex,q,P0);
%      L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
% J_norm1=my_Jacobian(a_d_alpha_theta0_norm,q,P0);%�����ݶ�
% %    Y0=J_norm1*x0+Ek;
% %      Pos_ex1=my_forward(a_d_alpha_theta0_ex,q);
% %     Pos_norm1=my_forward(a_d_alpha_theta0_norm,q);
% %  Pos_ex1=J_norm2*a_d_alpha_theta0_ex;
% %     K = P*J_norm1' / (J_norm1*P*J_norm1' + R);
% %     X = X + K * (Pos_ex1-J_norm1*X);
% %     P = P - K *J_norm1* P + Q;
% H=J_norm1;
% % H1=J_norm2;
% % X=a_d_alpha_theta0_norm;
% % Xkf=X;
% % Xkf=a_d_alpha_theta0_ex;
% %     Z=H*X;
%     X_pre=Xkf;           
%     P_pre=P+Q;        
%     Kg=P_pre*H'*pinv(H*P_pre*H'+R+0.0004*I1); 
%  %   e=Z-H*X_pre;  
%     e=L_norm1-L_ex11;
%    %e=H*X_pre-L_ex11;
%     Xkf=X_pre+Kg*e;         
%     P=(I-Kg*H)*P_pre;
% 
% end
% %end
% a_d_alpha_theta0_norm= Xkf;
% %end


%%�������˲��㷨
Iter=20;
MSE_store=zeros(0,1);
delta0=0;


x1 = a_d_alpha_theta0_norm; %��ʼֵ
xbest=x1;
fbest=fh(xbest,Data1);   

 for iteration=1:Iter
    
N = length(q1_batch);
K = zeros(24,24);
X = a_d_alpha_theta0_norm;
% P = 1e-5*eye(24);
% Q=1e-6*eye(24);
% R=1e-6*eye(3);
% P = 2e-7*eye(24);
% Q=2e-7*eye(24);
% R=2e-7*eye(1);
%%����������
P = 2e-10*eye(24);
Q=2e-10*eye(24);
R=2e-10*eye(1);
%%
I=eye(24);
I1=eye(1);
X=a_d_alpha_theta0_norm;
Xkf=X;
MSE=0;
% P_pre=0;
% Kg=zeros(24,1);
%for iteration=1:Iter
for i = 1:N%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
%     J_norm1=my_Jacobian(a_d_alpha_theta0_norm,q);
%     J_norm2=my_Jacobian(a_d_alpha_theta0_ex,q);
      L_ex11=MM1(i);
%     L_ex11=my_forward(a_d_alpha_theta0_ex,q,P0);
     L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
J_norm1=my_Jacobian(a_d_alpha_theta0_norm,q,P0);%�����ݶ�
%    Y0=J_norm1*x0+Ek;
%      Pos_ex1=my_forward(a_d_alpha_theta0_ex,q);
%     Pos_norm1=my_forward(a_d_alpha_theta0_norm,q);
%  Pos_ex1=J_norm2*a_d_alpha_theta0_ex;
%     K = P*J_norm1' / (J_norm1*P*J_norm1' + R);
%     X = X + K * (Pos_ex1-J_norm1*X);
%     P = P - K *J_norm1* P + Q;
H=J_norm1;
% H1=J_norm2;
% X=a_d_alpha_theta0_norm;
% Xkf=X;
% Xkf=a_d_alpha_theta0_ex;
%     Z=H*X;
    X_pre=Xkf;           
    P_pre=P+Q;        
    Kg=P_pre*H'*pinv(H*P_pre*H'+R+0.0004*I1); 
 %   e=Z-H*X_pre;  
%     e=L_norm1-L_ex11;
 e=H*X_pre-L_ex11;
    Xkf=X_pre+Kg*e;         
    P=(I-Kg*H)*P_pre;
Error=L_norm1-L_ex11;
 MSE=MSE+(norm(Error))^2;
end
MSE=MSE/length(q1_batch);
MSE=sqrt(MSE);
 MSE=MSE*1000;
MSE_store=[MSE_store;MSE];
%end
a_d_alpha_theta0_norm= Xkf;
X1=Xkf;


f1=fh(X1,Data1);

%%%%%%%%%%%

if f1<fbest

xbest=X1;

fbest=f1;

end

fitness_best1(iteration) = fh(xbest,Data1); %����ǰ���Ŵ��������
 end

 a_d_alpha_theta0_norm=xbest;
 
toc
%------------------------------------------
%���ݿ��ӻ�data visualization
%------------------------------------------
 format long
figure(1),clf(1),
% semilogy(MSE_store,'rx-')
semilogy(fitness_best1,'rx-')
%xlabel('Iteration');
xlabel('Iteration number');
%ylabel('MSE');
ylabel('Error/mm');
% display('Calibration Error:');
% %a_d_alpha_theta0_norm-a_d_alpha_theta0_ex
display('Calibrated Parameters:');
a_d_alpha_theta0_norm
P0
%------------------------------------------
%���Բ��֣������µ����ݼ����Ա궨Ч��
%------------------------------------------
%the above can be viewed as training from machine learning perspective
%the following is testing
% q=rands(6,1);
q11=[-67.7	24.7	-14.5	-14.9	75.1	-54.4];
q=q11*pi/180;
%L_ex11=my_forward(a_d_alpha_theta0_ex,q);
L_ex11=0.4845;
L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
J_norm1=my_Jacobian(a_d_alpha_theta0_norm,q,P0);
Error=L_norm1-L_ex11;
display(['Position error:',num2str(Error')]);
%testing data batch
% q1_batch = pi*rands(50,1);
% q2_batch = pi*rands(50,1);
% q3_batch = pi*rands(50,1);
% q4_batch = pi*rands(50,1);
% q5_batch = pi*rands(50,1);
% q6_batch = pi*rands(50,1);
q1_batch = U(:,1);
q2_batch = U(:,2);
q3_batch = U(:,3);
q4_batch = U(:,4);
q5_batch = U(:,5);
q6_batch = U(:,6);

MSE=0;
E_max2=0;
%--------
%a_d_alpha_theta0_ex=a_d_alpha_theta0_ex+0.4*rands(24,1);
for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
%     L_ex11=my_forward(a_d_alpha_theta0_ex,q);
    L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
    Error=L_norm1-L_ex11;
    MSE=MSE+(norm(Error))^2;
    E_max2=max((norm(Error))^2,E_max2);
end
%MSE=MSE/length(q1_batch);
%display(['Testing MSE:',num2str(MSE)]);
%display(['Max Error square:',num2str(E_max2)]);
MSE=MSE/length(q1_batch);
RMSE=sqrt(MSE);
E_max2=sqrt(E_max2);
display(['Testing RMSE:',num2str(RMSE)]);
display(['Max Error:',num2str(E_max2)]);
