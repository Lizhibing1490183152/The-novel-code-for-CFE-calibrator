%revision history:
%v1: Feb.5th, 2020,by Shuai Li
%v2: Feb. 11th,2020 by Shuai Li
clear all
close all
tic
%------------------------------------------
%�궨���֣��������ݼ����б궨
%�ⲿ���ǻ�������������pre_processing.m(����matlab���������ȡ���궨��е�۵�foward
%kinematics����Բ����㶯��Jacobian���󣩣�my_forward.m(��pre_processing.m��õ�forward
%kinematics����my_Jacobian.m����pre_processing.m��õ�Jacobian)��
%------------------------------------------
%ϵͳ������������е�۵���ʵ����ֵ���������ֵ��
%����˳��a1,a2,a3,a4,a5,a6,d1,d2,d3,d4,d5,d6,alpha1,alpha2,alpha3,alpha4,alpha5,alpha6,...
%theta0_1,theta0_2,theta0_3,theta0_4,theta0_5,theta0_6;
%a_d_alpha_theta0_ex=rand(24,1);%[];%�����˵���ʵ����a d alpha theta0
%     a_d_alpha_theta0_norm0=...
%     [0 0.4318 0.0203 0 0 0 ...
%     0 0 0.15 0.4318 0 0 ...
%     1.571 0 -1.571 1.571 -1.571 0 ...
%     0 0 0 0 0 0 ...
%     1,1.3,1.2]';
 a_d_alpha_theta0_norm0=...
     [0 0.27 0.07 0 0 0 ...
    0.29 0 0 0.302 0 0.072 ...
    -1.571 0 -1.571 1.571 -1.571 0 ...
    0 -1.57 0 0 0 0]';

%  a_d_alpha_theta0_norm0=...
% [-0.003544680574327
%    0.269677857928149
%    0.070076525442273
%    0.000035954797466
%   -0.000157631987001
%   -0.000044124086936
%    0.290095310375795
%   -0.000180200150986
%    0.000025291352522
%    0.301972445219093
%   -0.000004162924009
%    0.072004648921874
%   -1.570902323364732
%    0.000014829836949
%   -1.570734625007067
%    1.571660441130738
%   -1.571008405588589
%   -0.000107833258836
%    0.000249878611152
%   -1.569168372626613
%    0.008425424305972
%   -0.002814444193507
%    0.000466814076836
%   -0.001790419098562];

%a_d_alpha_theta0_norm=rand(24,1);%[];%�����˵��������a d alpha theta0
a_d_alpha_theta0_norm=a_d_alpha_theta0_norm0;
% a_d_alpha_theta0_ex=a_d_alpha_theta0_norm.*(1+0.01*rands(24,1));
% %a_d_alpha_theta0_ex=a_d_alpha_theta0_norm0;
% q1_batch = pi/2*rands(30,1);
% q2_batch = pi/2*rands(30,1);
% q3_batch = pi/2*rands(30,1);
% q4_batch = pi/2*rands(30,1);
% q5_batch = pi/2*rands(30,1);
% q6_batch = pi/2*rands(30,1);
Data1 = xlsread('Data.xlsx',1,'D2:J112');
Data2 = xlsread('Data.xlsx',2,'D2:J22');
U=Data1(:,1:6)*pi/180;
MM1=Data1(:,7)/1000;
UU=Data2(:,1:6)*pi/180;
VV1=Data2(:,7)/1000;

q1_batch = U(:,1);
q2_batch = U(:,2);
q3_batch = U(:,3);
q4_batch = U(:,4);
q5_batch = U(:,5);
q6_batch = U(:,6);

%------------------------------------------%------------------------------------------
%------------------------------------------%------------------------------------------
% Iter=100;
% Iter=15;
Iter=100;
MSE_store=zeros(0,1);
% K1=1e-7;
K1=1e-6;
v=0.00005*rands(1,1);
% P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
 %KH1=0.0004;
%KH1=1e-5;
KH1=3e-1;
%b=0.00001*rands(24,1);
b=0.001*rands(24,1);

for iteration=1:Iter
%------------------------------------------
%--------
delta0=0;
delta1=0;
MSE=0;

%--------
for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
    %L_ex11=my_forward(a_d_alpha_theta0_ex,q,P0);
    L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
    J_norm1=my_Jacobian(a_d_alpha_theta0_norm,q,P0);
    Error=L_norm1-L_ex11;
    MSE=MSE+(norm(Error))^2;
    delta0=delta0+J_norm1'*Error;
    delta1=delta1+J_norm1'*J_norm1;
  
end
delta0=delta0/length(q1_batch);
delta1=delta1/length(q1_batch);
MSE=MSE/length(q1_batch);
MSE_store=[MSE_store;MSE];
%a_d_alpha_theta0_ex=a_d_alpha_theta0_ex+0.4*rands(24,1);
%%%-------------
%Put your algorithm here
%Method 1: gradient
%a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-0.5*delta0;
%%%-------------
%Method 2: recursive least square
%a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-inv(delta1+0.0004*eye(24))*delta0;
  a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-pinv(delta1+KH1*eye(24))*delta0;
% a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-pinv(delta1)*delta0+0.0001*sign(a_d_alpha_theta0_norm);%��һ�ַ���
%a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-pinv(delta1)*(delta0+K1*sign(a_d_alpha_theta0_norm));%�ڶ��ּ����򻯷���

 %a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-pinv(delta1+KH1*eye(24))*(delta0+K1*( a_d_alpha_theta0_norm+a_d_alpha_theta0_norm*exp(-b'* a_d_alpha_theta0_norm)+((b'*a_d_alpha_theta0_norm)*a_d_alpha_theta0_norm')'*exp(-b'* a_d_alpha_theta0_norm))*pinv((1+exp(-b'* a_d_alpha_theta0_norm))^3));

%a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-pinv(delta1+KH1*eye(24))*(delta0+K1*a_d_alpha_theta0_norm*pinv(sqrt(a_d_alpha_theta0_norm'*a_d_alpha_theta0_norm+v)));%��3�ּ����򻯷���
 
 %a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-pinv(delta1+KH1*eye(24))*delta0;

end 
toc
%------------------------------------------
%���ݿ��ӻ�data visualization
%------------------------------------------
format long
figure(1),clf(1),
semilogy(MSE_store,'rx-')
xlabel('Iteration');
ylabel('MSE');
%display('Calibration Error:');
%a_d_alpha_theta0_norm-a_d_alpha_theta0_ex
display('Calibrated Parameters:');
a_d_alpha_theta0_norm
%------------------------------------------
%���Բ��֣������µ����ݼ����Ա궨Ч��
%------------------------------------------
%the above can be viewed as training from machine learning perspective
%the following is testing
% q=rands(6,1);
% L_ex11=my_forward(a_d_alpha_theta0_ex,q,P0);
q11=[-67.7	24.7	-14.5	-14.9	75.1	-54.4];
q=q11*pi/180;
%L_ex11=my_forward(a_d_alpha_theta0_ex,q);
L_ex11=0.4845;
L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
J_norm1=my_Jacobian(a_d_alpha_theta0_norm,q,P0);
Error=L_norm1-L_ex11;
display(['Position error:',num2str(Error')]);
%testing data batch
% q1_batch = pi*rands(50,1);
% q2_batch = pi*rands(50,1);
% q3_batch = pi*rands(50,1);
% q4_batch = pi*rands(50,1);
% q5_batch = pi*rands(50,1);
% q6_batch = pi*rands(50,1);


q1_batch = U(:,1);
q2_batch = U(:,2);
q3_batch = U(:,3);
q4_batch = U(:,4);
q5_batch = U(:,5);
q6_batch = U(:,6);

MSE=0;
E_max2=0;
%--------

for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
    %L_ex11=my_forward(a_d_alpha_theta0_ex,q,P0);
    %L_ex11=L_ex1(i);
    L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
    Error=L_norm1-L_ex11;
    MSE=MSE+(norm(Error))^2;
    E_max2=max((norm(Error))^2,E_max2);
end
%MSE=MSE/length(q1_batch);
%display(['Testing MSE:',num2str(MSE)]);
%display(['Max Error square:',num2str(E_max2)]);
MSE=MSE/length(q1_batch);
RMSE=sqrt(MSE);
E_max2=sqrt(E_max2);
display(['Testing RMSE:',num2str(RMSE)]);
display(['Max Error:',num2str(E_max2)]);
