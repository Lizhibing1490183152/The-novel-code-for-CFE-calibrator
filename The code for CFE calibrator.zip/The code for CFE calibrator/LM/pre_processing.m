clear all
close all  
%ʹ�÷��ź�������ʵ��ģ�ͣ�������
syms x0 y0 z0;
syms d1 d2 d3 d4 d5 d6;   %��е������ƫ��d
syms a1 a2 a3 a4 a5 a6;     %��е�����˳���a
syms theta0_1 theta0_2 theta0_3 theta0_4 theta0_5 theta0_6; %�ؽڽ���λ
syms alpha1 alpha2 alpha3 alpha4 alpha5 alpha6; %alpha
syms q1 q2 q3 q4 q5 q6;    %ת���Ƕ�
%------------------------------------------
%create robot model������ͨ��ģ�͵Ľ������÷��Ż�������
my_link(1) = Link([0, d1, a1, alpha1, 0], 'standard');%the last entry 0 means the joint is revolute,1 means primatic
my_link(2) = Link([0, d2, a2, alpha2, 0], 'standard');
my_link(3) = Link([0, d3, a3, alpha3, 0], 'standard');
my_link(4) = Link([0, d4, a4, alpha4, 0], 'standard');
my_link(5) = Link([0, d5, a5, alpha5, 0], 'standard');
my_link(6) = Link([0, d6, a6, alpha6, 0], 'standard');
Robot_model= SerialLink(my_link, 'name', 'robot_ex');   
%------------------------------------------
%��������
Pos = Robot_model.fkine([q1+theta0_1, q2+theta0_2, q3+theta0_3, q4+theta0_4, q5+theta0_5, q6+theta0_6]).t;   %ʵ��Ļ�е��λ��
Pos1= [x0; y0; z0];
L=norm(Pos-Pos1);
fid = fopen('C:\Users\Li Zhibin\Desktop\ceshi.txt', 'wt');
fprintf(fid, 'L=%s;',char(L));
fid = fclose(fid);
J = [...%Jacobian of Pos_norm relative to a,d,alpha,theta0
diff(L, a1), diff(L, a2),diff(L, a3), diff(L, a4),diff(L, a5), diff(L, a6),...
diff(L, d1), diff(L, d2),diff(L, d3), diff(L, d4), diff(L,d5), diff(L, d6),...
diff(L,alpha1), diff(L,alpha2),diff(L,alpha3), diff(L,alpha4), diff(L,alpha5), diff(L, alpha6),...
diff(L,theta0_1), diff(L,theta0_2),diff(L,theta0_3), diff(L,theta0_4), diff(L,theta0_5), diff(L, theta0_6),...
diff(L,x0), diff(L,y0),diff(L,z0)];
J
fid = fopen('C:\Users\Li Zhibin\Desktop\csd.txt', 'wt');
fprintf(fid, 'J(1,1)=%s;\n J(1,2)=%s;\n J(1,3)=%s;\n J(1,4)=%s;\n J(1,5)=%s;\n J(1,6)=%s;\n J(1,7)=%s;\n J(1,8)=%s;\n J(1,9)=%s;\n J(1,10)=%s;\n J(1,11)=%s;\n J(1,12)=%s;\n J(1,13)=%s;\n J(1,14)=%s;\n J(1,15)=%s;\n J(1,16)=%s;\n J(1,17)=%s;\n J(1,18)=%s;\n J(1,19)=%s;\n J(1,20)=%s;\n J(1,21)=%s;\n J(1,22)=%s;\n J(1,23)=%s;\n J(1,24)=%s;\n J(1,25)=%s;\n J(1,26)=%s;\n J(1,27)=%s;',char(J(1,1)),char(J(1,2)),char(J(1,3)),char(J(1,4)),char(J(1,5)),char(J(1,6)),char(J(1,7)),char(J(1,8)),char(J(1,9)),char(J(1,10)),char(J(1,11)),char(J(1,12)),char(J(1,13)),char(J(1,14)),char(J(1,15)),char(J(1,16)),char(J(1,17)),char(J(1,18)),char(J(1,19)),char(J(1,20)),char(J(1,21)),char(J(1,22)),char(J(1,23)),char(J(1,24)),char(J(1,25)),char(J(1,26)),char(J(1,27)));
fid = fclose(fid);