a_d_alpha_theta0_norm0=...
    [0 0.27 0.07 0 0 0 ...
    0.29 0 0 0.302 0 0.072 ...
    -1.571 0 -1.571 1.571 -1.571 0 ...
    0 -1.57 0 0 0 0]';
qq=[[0.00129100926013659;0.00225467791884527;0.00233251869313359;0.00226047365785826;0.00118910946307323;0.00191036431786966]];
% a_d_alpha_theta0_norm(1)=a_d_alpha_theta0_norm(1)*1000;
% a_d_alpha_theta0_norm(2)=a_d_alpha_theta0_norm(2)*1000;
% a_d_alpha_theta0_norm(3)=a_d_alpha_theta0_norm(3)*1000;
% a_d_alpha_theta0_norm(4)=a_d_alpha_theta0_norm(4)*1000;
% a_d_alpha_theta0_norm(5)=a_d_alpha_theta0_norm(5)*1000;
% a_d_alpha_theta0_norm(6)=a_d_alpha_theta0_norm(6)*1000;
% a_d_alpha_theta0_norm(7)=a_d_alpha_theta0_norm(7)*1000;
% a_d_alpha_theta0_norm(8)=a_d_alpha_theta0_norm(8)*1000;
% a_d_alpha_theta0_norm(9)=a_d_alpha_theta0_norm(9)*1000;
% a_d_alpha_theta0_norm(10)=a_d_alpha_theta0_norm(10)*1000;
% a_d_alpha_theta0_norm(11)=a_d_alpha_theta0_norm(11)*1000;
% a_d_alpha_theta0_norm(12)=a_d_alpha_theta0_norm(12)*1000;
% a_d_alpha_theta0_norm(13)=a_d_alpha_theta0_norm(13)*180/pi;
% a_d_alpha_theta0_norm(14)=a_d_alpha_theta0_norm(14)*180/pi;
% a_d_alpha_theta0_norm(15)=a_d_alpha_theta0_norm(15)*180/pi;
% a_d_alpha_theta0_norm(16)=a_d_alpha_theta0_norm(16)*180/pi;
% a_d_alpha_theta0_norm(17)=a_d_alpha_theta0_norm(17)*180/pi;
% a_d_alpha_theta0_norm(18)=a_d_alpha_theta0_norm(18)*180/pi;
% a_d_alpha_theta0_norm(19)=a_d_alpha_theta0_norm(19)*180/pi;
% a_d_alpha_theta0_norm(20)=a_d_alpha_theta0_norm(20)*180/pi;
% a_d_alpha_theta0_norm(21)=a_d_alpha_theta0_norm(21)*180/pi;
% a_d_alpha_theta0_norm(22)=a_d_alpha_theta0_norm(22)*180/pi;
% a_d_alpha_theta0_norm(23)=a_d_alpha_theta0_norm(23)*180/pi;
% a_d_alpha_theta0_norm(24)=a_d_alpha_theta0_norm(24)*180/pi;
a_d_alpha_theta0_norm(1)=a_d_alpha_theta0_norm0(1);
a_d_alpha_theta0_norm(2)=a_d_alpha_theta0_norm0(2);
a_d_alpha_theta0_norm(3)=a_d_alpha_theta0_norm0(3);
a_d_alpha_theta0_norm(4)=a_d_alpha_theta0_norm0(4);
a_d_alpha_theta0_norm(5)=a_d_alpha_theta0_norm0(5);
a_d_alpha_theta0_norm(6)=a_d_alpha_theta0_norm0(6);
a_d_alpha_theta0_norm(7)=a_d_alpha_theta0_norm0(7);
a_d_alpha_theta0_norm(8)=a_d_alpha_theta0_norm0(8);
a_d_alpha_theta0_norm(9)=a_d_alpha_theta0_norm0(9);
a_d_alpha_theta0_norm(10)=a_d_alpha_theta0_norm0(10);
a_d_alpha_theta0_norm(11)=a_d_alpha_theta0_norm0(11);
a_d_alpha_theta0_norm(12)=a_d_alpha_theta0_norm0(12);
a_d_alpha_theta0_norm(13)=a_d_alpha_theta0_norm0(13);
a_d_alpha_theta0_norm(14)=a_d_alpha_theta0_norm0(14);
a_d_alpha_theta0_norm(15)=a_d_alpha_theta0_norm0(15);
a_d_alpha_theta0_norm(16)=a_d_alpha_theta0_norm0(16);
a_d_alpha_theta0_norm(17)=a_d_alpha_theta0_norm0(17);
a_d_alpha_theta0_norm(18)=a_d_alpha_theta0_norm0(18);
a_d_alpha_theta0_norm(19)=a_d_alpha_theta0_norm0(19)+qq(1);
a_d_alpha_theta0_norm(20)=a_d_alpha_theta0_norm0(20)+qq(2);
a_d_alpha_theta0_norm(21)=a_d_alpha_theta0_norm0(21)+qq(3);
a_d_alpha_theta0_norm(22)=a_d_alpha_theta0_norm0(22)+qq(4);
a_d_alpha_theta0_norm(23)=a_d_alpha_theta0_norm0(23)+qq(5);
a_d_alpha_theta0_norm(24)=a_d_alpha_theta0_norm0(24)+qq(6);
format long
a_d_alpha_theta0_norm


