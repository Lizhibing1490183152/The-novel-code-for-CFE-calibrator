clc;
clear;
tic
a_d_alpha_theta0_norm0=...
     [0 0.27 0.07 0 0 0 ...
    0.29 0 0 0.302 0 0.072 ...
    -1.571 0 -1.571 1.571 -1.571 0 ...
    0 -1.57 0 0 0 0]';
%a_d_alpha_theta0_noa_d_alpha_theta0_normrm=rand(24,1);%[];%�����˵��������a d alpha theta0
a_d_alpha_theta0_norm=a_d_alpha_theta0_norm0;
% a_d_alpha_theta0_ex=a_d_alpha_theta0_norm.*(1+0.01*rands(24,1));
% %a_d_alpha_theta0_ex=a_d_alpha_theta0_norm0;
% q1_batch = pi/2*rands(30,1);
% q2_batch = pi/2*rands(30,1);
% q3_batch = pi/2*rands(30,1);
% q4_batch = pi/2*rands(30,1);
% q5_batch = pi/2*rands(30,1);
% q6_batch = pi/2*rands(30,1);
Data1 = xlsread('Data.xlsx',1,'D2:J112');
Data2 = xlsread('Data.xlsx',2,'D2:J22');
U=Data1(:,1:6)*pi/180;
MM1=Data1(:,7)/1000;
UU=Data2(:,1:6)*pi/180;
VV1=Data2(:,7)/1000;

q1_batch = U(:,1);
q2_batch = U(:,2);
q3_batch = U(:,3);
q4_batch = U(:,4);
q5_batch = U(:,5);
q6_batch = U(:,6);
P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��


X=0.2;
y_true=0.1;
beetles=a_d_alpha_theta0_norm';
V=a_d_alpha_theta0_norm';
weights_shape=2;
step=0.1;
n_beetles=24;
c1=0.1;
c2=0.1;
V_max=0.1;
V_min=0.2;
lambda=0.1
epoch=20;
max_epochs=30;
i_best=0.1*rands(1,24);
g_best=0.2;
activations=0.5;

omega_max = 0.9;
    omega_min = 0.4;
%     figure(1)
%     color = ['r','g','b','k','y'];
    temp = floor(size(beetles,1)/3);
    a_d_alpha_theta0_norm22=...
[ 0.000721274290792
   0.266441301555988
   0.070000000000000
   0.000000000000000
  -0.000000000000001
  -0.006518299457267
   0.290790406698613
   0.002877493764307
   0.002875682158873
   0.301737493820960
   0.000918402652134
   0.072000000000000
  -1.567557607169525
  -0.000057592388932
  -1.570227249116996
   1.571222991304497
  -1.570907296870046
  -0.000000000000000
  -0.000000000000000
  -1.570000000000000
   0.005035008654461
   0.000060750236533
   0.001075101068352
   0.000021771164074];
        %(8)
        omega = omega_max - (omega_max-omega_min)*epoch/max_epochs;
        %(5)
        dist = step / c2;
        prev_err = Inf(1,n_beetles);
        for i = 1:n_beetles
            v_beetle_curr = beetles(:,i);
%             scatter3(mean(v_beetle_curr((1:temp))),mean(v_beetle_curr(temp:temp * 2)),mean(v_beetle_curr((temp * 2:end))),color(i))
%             gif
%             hold on
            
%             disp(size(beetles))
%             disp(weights_shape)
%             disp(size(v_beetle_curr))
%             beetle_curr = pack_weights(v_beetle_curr,weights_shape);
%             [y_pred,~,~] = calc_ann(X,beetle_curr,activations);
%             prev_err(i) = calc_mse(y_pred,y_true);
            %(10)get antennae position x_r , x_l
            v_xr = v_beetle_curr + V(:,i) * dist / 2;
            v_xl = v_beetle_curr - V(:,i) * dist / 2;
%             xr = pack_weights(v_xr,weights_shape);
%             xl = pack_weights(v_xl,weights_shape);
            %(9) Update the incremental function
%             [y_pred_r,~,~] = calc_ann(X,xr,activations);
%             [y_pred_l,~,~] = calc_ann(X,xl,activations);

% f1=fh(chrom_best(1:end-1)'+a_d_alpha_theta0_norm,Data1);

            err_r = fh(v_xr+a_d_alpha_theta0_norm,Data1);
            err_l = fh(v_xl+a_d_alpha_theta0_norm,Data1);
            
            zeta = step * V(:,i) * sign(err_r-err_l);
            
            %(7)
            r1 = rand(1);
            r2 = rand(1);
          
            
            V(:,i) = omega*V(:,i)+c1*r1*(i_best(:,i)-beetles(:,i))+c2*r2*(g_best-beetles(:,i));
            
            
            %-beetles(:,i))+c2*r2*(g_best-beetles(:,i));
            id = find(abs(V) < V_min);
            V(id) = sign(V(id)) * V_min;
            id = find(abs(V) > V_max);
            V(id) = sign(V(id)) * V_max;
            %(6) Update the position of the current search agent
            beetles(:,i) = v_beetle_curr + lambda * V(:,i) + (1-lambda) * zeta;
            
           k22=a_d_alpha_theta0_norm22; 
        end
        V=k22;
 %���Բ���

q1_batch = U(:,1);
q2_batch = U(:,2);
q3_batch = U(:,3);
q4_batch = U(:,4);
q5_batch = U(:,5);
q6_batch = U(:,6);

MSE=0;
E_max2=0;
%--------

for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
    %L_ex11=my_forward(a_d_alpha_theta0_ex,q,P0);
    %L_ex11=L_ex1(i);
    L_ex11=MM1(i);
    L_norm1=my_forward(V,q,P0);
    Error=L_norm1-L_ex11;
    MSE=MSE+(norm(Error))^2;
    E_max2=max((norm(Error))^2,E_max2);
end
%MSE=MSE/length(q1_batch);
%display(['Testing MSE:',num2str(MSE)]);
%display(['Max Error square:',num2str(E_max2)]);
MSE=MSE/length(q1_batch);
RMSE=sqrt(MSE);
E_max2=sqrt(E_max2);
display(['Testing RMSE:',num2str(RMSE)]);
display(['Max Error:',num2str(E_max2)]);
    


