%revision history:
%v1: Feb.5th, 2020,by Shuai Li
%v2: Feb. 11th,2020 by Shuai Li
clear all
close all
tic
%------------------------------------------
%�궨���֣��������ݼ����б궨
%�ⲿ���ǻ�������������pre_processing.m(����matlab���������ȡ���궨��е�۵�foward
%kinematics����Բ����㶯��Jacobian���󣩣�my_forward.m(��pre_processing.m��õ�forward
%kinematics����my_Jacobian.m����pre_processing.m��õ�Jacobian)��
%------------------------------------------
%ϵͳ������������е�۵���ʵ����ֵ���������ֵ��
%����˳��a1,a2,a3,a4,a5,a6,d1,d2,d3,d4,d5,d6,alpha1,alpha2,alpha3,alpha4,alpha5,alpha6,...
%theta0_1,theta0_2,theta0_3,theta0_4,theta0_5,theta0_6;
%a_d_alpha_theta0_ex=rand(24,1);%[];%�����˵���ʵ����a d alpha theta0
%     a_d_alpha_theta0_norm0=...
%     [0 0.4318 0.0203 0 0 0 ...
%     0 0 0.15 0.4318 0 0 ...
%     1.571 0 -1.571 1.571 -1.571 0 ...
%     0 0 0 0 0 0 ...
%     1,1.3,1.2]';

Data1 = xlsread('Data.xlsx',1,'D2:J112');
Data2 = xlsread('Data.xlsx',2,'D2:J22');
U=Data1(:,1:6)*pi/180;
MM1=Data1(:,7)/1000;
% UU=Data2(:,1:6)*pi/180;
% VV1=Data2(:,7)/1000;

n=1;
omega1=0;
omega2=0;
omega3=0;
omega4=0;
omega5=0;
omega6=0;
omega7=0;
omega8=0;
omega=0;
KK=0;
KM=0;
% omega11=boosting1();%L1����
%     K1=omega11(1,1);
%     K11=omega11(2:25,:);
%     
%  omega22=boosting2();%L2����
%     K2=omega22(1,1);
%     K22=omega22(2:25,:);
%     
%     omega33=boosting3();%Elastic����
%     K3=omega33(1,1);
%     K33=omega33(2:25,:);
%     
%      omega44=boosting4();%Dropout����
%     K4=omega44(1,1);
%     K44=omega44(2:25,:);
%     
%        omega55=boosting5();%log����
%     K5=omega55(1,1);
%     K55=omega55(2:25,:);
%     
%        omega66=boosting6();%swish����
%     K6=omega66(1,1);
%     K66=omega66(2:25,:);

omega122=boosting12();%L1����

K1=omega122(1,1);
    K11=omega122(9:32,:);
    K11=K1*K11;
    
    K2=omega122(2,1);
    K22=omega122(33:56,:);
    K22=K2*K22;
   
    K3=omega122(3,1);
    K33=omega122(57:80,:);
    K33=K3*K33;
     
    K4=omega122(4,1);
    K44=omega122(81:104,:);
    K44=K4*K44;
    
    K5=omega122(5,1);
    K55=omega122(105:128,:);
    K55=K5*K55;
      
    K6=omega122(6,1);
    K66=omega122(129:152,:);
    K66=K6*K66;
    
     K7=omega122(7,1);
    K77=omega122(153:176,:);
    K77=K7*K77;
      
    K8=omega122(8,1);
    K88=omega122(177:200,:);
    K88=K8*K88;

    
for i= 1:n
    
    omega1=omega1+K1;
    
end

for i= 1:n
    
    omega2=omega2+K2;
end

for i= 1:n
    
    omega3=omega3+K3;
end
for i= 1:n
    
    omega4=omega4+K4;
end

for i= 1:n
    
    omega5=omega5+K5;
end

for i= 1:n
    
    omega6=omega6+K6;
end

for i= 1:n
    
    omega7=omega7+K7;
end

for i= 1:n
    
    omega8=omega8+K8;
end

% omega=omega1+omega2;%L1+L2
% KK=K11+K22;

% omega=omega1+omega2+omega3;%L1+L2+Elastic
% KK=K11+K22+K33;

% omega=omega1+omega2+omega3+omega4;%L1+L2+Elastic+Dropout
% KK=K11+K22+K33+K44;

% omega=omega1+omega2+omega3+omega4+omega5;%L1+L2+Elastic+Dropout+log
% KK=K11+K22+K33+K44+K55;

% omega=omega1+omega2+omega3+omega4+omega5+omega6;%L1+L2+Elastic+Dropout+log+swish
% KK=K11+K22+K33+K44+K55+K66;

% omega=omega6+omega4;%M4+����
% KK=K66+K44;

omega=omega1+omega2+omega3+omega4+omega5+omega6+omega7+omega8;%L1+L2+Elastic+Dropout+log+swish
KK=K11+K22+K33+K44+K55+K66+K77+K88;



KM=KK/omega;
a_d_alpha_theta0_norm=KM;

toc

P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
format long
display('Calibrated Parameters:');
a_d_alpha_theta0_norm

%  a_d_alpha_theta0_norm0=...
%      [0 0.27 0.07 0 0 0 ...
%     0.29 0 0 0.302 0 0.072 ...
%     -1.571 0 -1.571 1.571 -1.571 0 ...
%     0 -1.57 0 0 0 0]';
% %a_d_alpha_theta0_norm=rand(24,1);%[];%�����˵��������a d alpha theta0
% a_d_alpha_theta0_norm=a_d_alpha_theta0_norm0;
% % a_d_alpha_theta0_ex=a_d_alpha_theta0_norm.*(1+0.01*rands(24,1));
% % %a_d_alpha_theta0_ex=a_d_alpha_theta0_norm0;
% % q1_batch = pi/2*rands(30,1);
% % q2_batch = pi/2*rands(30,1);
% % q3_batch = pi/2*rands(30,1);
% % q4_batch = pi/2*rands(30,1);
% % q5_batch = pi/2*rands(30,1);
% % q6_batch = pi/2*rands(30,1);
% Data1 = xlsread('Data.xlsx',1,'D2:J112');
% Data2 = xlsread('Data.xlsx',2,'D2:J22');
% U=Data1(:,1:6)*pi/180;
% MM1=Data1(:,7)/1000;
% UU=Data2(:,1:6)*pi/180;
% VV1=Data2(:,7)/1000;
% 
% q1_batch = U(:,1);
% q2_batch = U(:,2);
% q3_batch = U(:,3);
% q4_batch = U(:,4);
% q5_batch = U(:,5);
% q6_batch = U(:,6);
% 
% %------------------------------------------%------------------------------------------
% %------------------------------------------%------------------------------------------
% Iter=100;
% MSE_store=zeros(0,1);
% K1=1e-7;
% v=0.00005*rands(1,1);
% % P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
% P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
% % KH1=0.0004;
% KH1=1e-5;
% b=0.00001*rands(24,1);
% 
% for iteration=1:Iter
% %------------------------------------------
% %--------
% delta0=0;
% delta1=0;
% MSE=0;
% 
% %--------
% for i = 1:length(q1_batch)%each i represent one measurement
%     q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
%     %L_ex11=my_forward(a_d_alpha_theta0_ex,q,P0);
%     L_ex11=MM1(i);
%     L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
%     J_norm1=my_Jacobian(a_d_alpha_theta0_norm,q,P0);
%     Error=L_norm1-L_ex11;
%     MSE=MSE+(norm(Error))^2;
%     delta0=delta0+J_norm1'*Error;
%     delta1=delta1+J_norm1'*J_norm1;
%   
% end
% delta0=delta0/length(q1_batch);
% delta1=delta1/length(q1_batch);
% MSE=MSE/length(q1_batch);
% MSE_store=[MSE_store;MSE];
% %a_d_alpha_theta0_ex=a_d_alpha_theta0_ex+0.4*rands(24,1);
% %%%-------------
% %Put your algorithm here
% %Method 1: gradient
% %a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-0.5*delta0;
% %%%-------------
% %Method 2: recursive least square
% %a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-inv(delta1+0.0004*eye(24))*delta0;
% %  a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-pinv(delta1+0.0004*eye(27))*delta0;
% % a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-pinv(delta1)*delta0+0.0001*sign(a_d_alpha_theta0_norm);%��һ�ַ���
% %a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-pinv(delta1)*(delta0+K1*sign(a_d_alpha_theta0_norm));%�ڶ��ּ����򻯷���
% 
%  %a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-pinv(delta1+KH1*eye(24))*(delta0+K1*( a_d_alpha_theta0_norm+a_d_alpha_theta0_norm*exp(-b'* a_d_alpha_theta0_norm)+((b'*a_d_alpha_theta0_norm)*a_d_alpha_theta0_norm')'*exp(-b'* a_d_alpha_theta0_norm))*pinv((1+exp(-b'* a_d_alpha_theta0_norm))^3));
% 
% a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-pinv(delta1+KH1*eye(24))*(delta0+K1*a_d_alpha_theta0_norm*pinv(sqrt(a_d_alpha_theta0_norm'*a_d_alpha_theta0_norm+v)));%��3�ּ����򻯷���
%  
%  %a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-pinv(delta1+KH1*eye(24))*delta0;
% 
% end 
% toc
% %------------------------------------------
% %���ݿ��ӻ�data visualization
% %------------------------------------------
% format long
% figure(1),clf(1),
% semilogy(MSE_store,'rx-')
% xlabel('Iteration');
% ylabel('MSE');
% %display('Calibration Error:');
% %a_d_alpha_theta0_norm-a_d_alpha_theta0_ex
% display('Calibrated Parameters:');
% a_d_alpha_theta0_norm
%------------------------------------------
%���Բ��֣������µ����ݼ����Ա궨Ч��
%------------------------------------------
%the above can be viewed as training from machine learning perspective
%the following is testing
% q=rands(6,1);
% L_ex11=my_forward(a_d_alpha_theta0_ex,q,P0);
q11=[-67.7	24.7	-14.5	-14.9	75.1	-54.4];
q=q11*pi/180;
%L_ex11=my_forward(a_d_alpha_theta0_ex,q);
L_ex11=0.4845;
L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
J_norm1=my_Jacobian(a_d_alpha_theta0_norm,q,P0);
Error=L_norm1-L_ex11;
display(['Position error:',num2str(Error')]);
%testing data batch
% q1_batch = pi*rands(50,1);
% q2_batch = pi*rands(50,1);
% q3_batch = pi*rands(50,1);
% q4_batch = pi*rands(50,1);
% q5_batch = pi*rands(50,1);
% q6_batch = pi*rands(50,1);


q1_batch = U(:,1);
q2_batch = U(:,2);
q3_batch = U(:,3);
q4_batch = U(:,4);
q5_batch = U(:,5);
q6_batch = U(:,6);

MSE=0;
E_max2=0;
%--------

for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
    %L_ex11=my_forward(a_d_alpha_theta0_ex,q,P0);
    %L_ex11=L_ex1(i);
    L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
    Error=L_norm1-L_ex11;
    MSE=MSE+(norm(Error))^2;
    E_max2=max((norm(Error))^2,E_max2);
end
%MSE=MSE/length(q1_batch);
%display(['Testing MSE:',num2str(MSE)]);
%display(['Max Error square:',num2str(E_max2)]);
MSE=MSE/length(q1_batch);
RMSE=sqrt(MSE);
E_max2=sqrt(E_max2);
display(['Testing RMSE:',num2str(RMSE)]);
display(['Max Error:',num2str(E_max2)]);
