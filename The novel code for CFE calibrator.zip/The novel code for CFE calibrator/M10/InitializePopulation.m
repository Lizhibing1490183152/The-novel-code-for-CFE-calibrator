% Initializing population between [LB, UB]
function pop = InitializePopulation(N, d, xmin, xmax)

x = zeros(N, d);
for i=1:d
    x(1:N, i) = repmat(xmin(i), N, 1) + (xmax(i) - xmin(i)) * rand(N,1);
end
pop = zeros(N, d+1); 
pop(:, 1:d) = x;