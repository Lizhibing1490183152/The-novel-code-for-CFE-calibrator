% Recombination operator with elite preservation strategy
%
function pop = recombine(pop1, pop2)
global CostFunction
[N, d] = size(pop1); d = d-1;
pop2 = [pop2, zeros(N, 1)];
for i=1:N
    pop2(i,end)=CostFunction(pop2(i,1:d));
end
pop3 = [pop1; pop2];
pop3 = pop3( randperm(2*N), :); % Shuffle pop3
tournament = randperm(2*N);
% Competition Begins
pop = zeros(N, d+1);
ID = zeros(N,1);
count = 0;
for i=1:2:2*N
    fitness = pop3( tournament(i:i+1), d+1 );
    min_member = find(fitness == min(fitness));
    count = count + 1;
    ID(count) = tournament(i-1+min_member(1));
    pop(count, :) = pop3( ID(count), :);
end


