% TOURNAMENT SELECTION
%
function pop_selection = Tournament(pop, d)
N = size(pop,1);
tournament1 = randperm(N);
tournament2 = randperm(N);
tournament = [tournament1, tournament2]; % Tournament with tournament size equal to 2
% Competition Begins
pop_selection = zeros(N, d); % Only the decision variables of the selected members
ID = zeros(N,1);
count = 0;
for i=1:2:2*N
    fitness = pop(tournament(i:i+1), d+1);
    min_member = find(fitness == min(fitness));
    count = count + 1;
    ID(count) = tournament(i-1+min_member(1));
    pop_selection(count, 1:d) = pop( ID(count), 1:d);
end

