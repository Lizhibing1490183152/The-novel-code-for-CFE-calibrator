% Directional Mutation (DM) Operator
function pop_mutation = DM( pop_crossover, p_mutation, xmin, xmax,pc,pd)
[N, d] = size(pop_crossover); % Population size & Number of variables
pop_mutation = pop_crossover;
for ind = 1:N
    for i = 1:d
        y = pop_mutation(ind,i);
        yl = xmin(i);
        yu = xmax(i);
        r = (rand);
        if rand <= p_mutation % every var is mutated with prob p_mut
            beta1=exp(2*r-2/r);
            beta2=exp(r-2/r);
            if(pc(1,i)>=y)
                if(rand<=pd)
                    y=y+beta1*(yu-y);
                else
                    y=y-beta2*(y-yl);
                end
            else
                if(rand<=pd)
                    y=y-beta1*(y-yl);
                else
                    y=y+beta2*(yu-y);
                end
            end
        end
        pop_mutation(ind,i) = y;
    end
end
end

