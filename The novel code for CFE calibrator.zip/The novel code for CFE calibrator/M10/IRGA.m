%%
% This is the Matlab code for Improved Real-coded Genetic Algorithm (IRGA)
% The proposed IRGA consists of Tournament Selection with tournament size
% 2,Directional Crossover (DX), Directional Mutation (DM) and a
% recombination operators. This solves minimization problems. 
% For details of the algorithm, please read and cite the below mentioned
% paper:

% A. K. Das and D. K. Pratihar, "Solving engineering optimization problems using an improved 
% real-coded genetic algorithm (IRGA) with directional mutation and crossover," Soft Computing, 
% vol. 25, pp. 5455-5481, 2021.
%%

clc;
clear;
tic
a_d_alpha_theta0_norm0=...
     [0 0.27 0.07 0 0 0 ...
    0.29 0 0 0.302 0 0.072 ...
    -1.571 0 -1.571 1.571 -1.571 0 ...
    0 -1.57 0 0 0 0]';
%a_d_alpha_theta0_norm=rand(24,1);%[];%�����˵��������a d alpha theta0
a_d_alpha_theta0_norm=a_d_alpha_theta0_norm0;
% a_d_alpha_theta0_ex=a_d_alpha_theta0_norm.*(1+0.01*rands(24,1));
% %a_d_alpha_theta0_ex=a_d_alpha_theta0_norm0;
% q1_batch = pi/2*rands(30,1);
% q2_batch = pi/2*rands(30,1);
% q3_batch = pi/2*rands(30,1);
% q4_batch = pi/2*rands(30,1);
% q5_batch = pi/2*rands(30,1);
% q6_batch = pi/2*rands(30,1);
Data1 = xlsread('Data.xlsx',1,'D2:J112');
Data2 = xlsread('Data.xlsx',2,'D2:J22');
U=Data1(:,1:6)*pi/180;
MM1=Data1(:,7)/1000;
UU=Data2(:,1:6)*pi/180;
VV1=Data2(:,7)/1000;

q1_batch = U(:,1);
q2_batch = U(:,2);
q3_batch = U(:,3);
q4_batch = U(:,4);
q5_batch = U(:,5);
q6_batch = U(:,6);
P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��

tic
global CostFunction
d=4 ; % Number of variables
CostFunction = @(x) Sphere(x);  % Function allocation
xmin=[-100 -100 -100 -100]; % Lower boundaries of variables
xmax=[100 100 100 100]; % Upper boundaries of variables
%% Common Parameters
max_gen=30; % Maximum number of generation
N=24; % Population size. Here, N must be an even number
% if mod(N,2) ~= 0
%     disp ("Population size (N) must be an even number to compare pairs");
%     return;
% end
%% Algorithm-specific parameters 
p_mutation=0.03; % mutation probability (generally assign a lower probability value near 1/d, d is the no. of variables)
p_crossover=0.98; % crossover probability (generally assign a higher probability value near to 1.0)
mf=0.95; % multiplying factor (generally vary from 0.9 to 0.9999)
p_cross_var=0.94; % variable-wise crossover probability (generally assign a higher probability value near to 1.0)
pd=0.5; % directional probability (may vary from 0.5 to 1)
%--------------------------------------------------------------------------
% Generate initial population of solutions
%--------------------------------------------------------------------------
pop = 0.001*InitializePopulation(N, d, xmin, xmax);
%--------------------------------------------------------------------------
% Determine fitness
%--------------------------------------------------------------------------
% NOTE: All objectives should be of MINIMIZATION type
x11 = a_d_alpha_theta0_norm; %��ʼֵ

xbest=x11;
KL=5;

    
  fbest=fh(xbest,Data1);  
  
for i=1:N
    pop(i,end)=CostFunction(pop(i,1:d));
end
gen = 1; % Generation # 0
[cbest, BESTID] = min( pop(:, d+1) ); % cbest: Current best fitness
convergence_curve=zeros(max_gen,1);
convergence_curve(gen,1)=cbest;
%--------------------------------------------------------------------------
% Begin generations
%--------------------------------------------------------------------------
while (gen<max_gen)
    %--------------------------------------------------------------
    % Tournament Selection
    %--------------------------------------------------------------
     pop_selection = Tournament(pop, d);

    %--------------------------------------------------------------
    % Directional CROSSOVER (DX)
    %--------------------------------------------------------------
    
    pop_crossover = DX( pop_selection, xmin, xmax,p_cross_var,pop(BESTID,1:d),p_crossover,mf,pd);
    
    %--------------------------------------------------------------
    % Directional MUTATION (DM)
    %--------------------------------------------------------------
    
    pop_mut = DM( pop_crossover, p_mutation, xmin, xmax,pop(BESTID,1:d),pd);

   
    % --------------------------------------------------------------- %
    % MERGE PARENTS & CHILDREN, and REDUCE POPULATION SIZE TO N APPLYING
    % TOURNAMENT SELECTION
    % --------------------------------------------------------------- %

    pop = recombine(pop, pop_mut); % elite preservation

    % --------------------------------------------------------------- %
    % REPORT
    % --------------------------------------------------------------- %
    [cbest, BESTID] = min( pop(:, d+1) );
    gen = gen+1;
%     disp(['Generation = ' num2str( gen) ':Best Individual Fitness = ' num2str( cbest)]);
    convergence_curve(gen,1)=cbest;
    
    for i=1:KL
        PP1=pop(:,i);
    
f1=fh(PP1+a_d_alpha_theta0_norm,Data1);

%%%%%%%%%%%

if f1<fbest

xbest=PP1;

fbest=f1;
end
    end   
end

% disp(['Best Solution = ' num2str( pop(BESTID,1:d))]);
% plot(convergence_curve);
% xlabel("Number of generation");
% ylabel("Best fitness");
% title ("Convergence plot");
toc
%���Բ���

q1_batch = U(:,1);
q2_batch = U(:,2);
q3_batch = U(:,3);
q4_batch = U(:,4);
q5_batch = U(:,5);
q6_batch = U(:,6);

MSE=0;
E_max2=0;
%--------

for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
    %L_ex11=my_forward(a_d_alpha_theta0_ex,q,P0);
    %L_ex11=L_ex1(i);
    L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm+xbest,q,P0);
    Error=L_norm1-L_ex11;
    MSE=MSE+(norm(Error))^2;
    E_max2=max((norm(Error))^2,E_max2);
end
%MSE=MSE/length(q1_batch);
%display(['Testing MSE:',num2str(MSE)]);
%display(['Max Error square:',num2str(E_max2)]);
MSE=MSE/length(q1_batch);
RMSE=sqrt(MSE);
E_max2=sqrt(E_max2);
display(['Testing RMSE:',num2str(RMSE)]);
display(['Max Error:',num2str(E_max2)]);
format long
a_d_alpha_theta0_norm+xbest
