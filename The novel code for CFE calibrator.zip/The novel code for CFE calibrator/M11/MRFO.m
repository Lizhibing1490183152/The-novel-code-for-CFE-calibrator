clear all
close all
%--------------------------------------------------------------------------
% MRFO code v1.0.
% Developed in MATLAB R2011b
% The code is based on the following papers.
% W. Zhao, Z. Zhang and L. Wang, Manta ray foraging optimization: An
% effective bio-inspired optimizer for engineering applications.
% Engineering Applications of Artifical Intelligence (2019),
% https://dio.org/10.1016/j.engappai.2019.103300.
% -------------------------------------------------------------------------
% FunIndex: Index of function.
% MaxIt: The maximum number of iterations.
% PopSize: The size of population.
% PopPos: The position of population.
% PopFit: The fitness of population.
% Dim: The dimensionality of prloblem.
% Alpha: The weight coefficient in chain foraging.
% Beta: The weight coefficient in cyclone foraging.
% S: The somersault factor.
% BestF: The best fitness corresponding to BestX. 
% HisBestFit: History best fitness over iterations. 
% Low: The low bound of search space.
% Up: The up bound of search space.

a_d_alpha_theta0_norm0=...
     [0 0.27 0.07 0 0 0 ...
    0.29 0 0 0.302 0 0.072 ...
    -1.571 0 -1.571 1.571 -1.571 0 ...
    0 -1.57 0 0 0 0]';
%a_d_alpha_theta0_norm=rand(24,1);%[];%�����˵��������a d alpha theta0
a_d_alpha_theta0_norm=a_d_alpha_theta0_norm0;
% a_d_alpha_theta0_ex=a_d_alpha_theta0_norm.*(1+0.01*rands(24,1));
% %a_d_alpha_theta0_ex=a_d_alpha_theta0_norm0;
% q1_batch = pi/2*rands(30,1);
% q2_batch = pi/2*rands(30,1);
% q3_batch = pi/2*rands(30,1);
% q4_batch = pi/2*rands(30,1);
% q5_batch = pi/2*rands(30,1);
% q6_batch = pi/2*rands(30,1);
Data1 = xlsread('Data.xlsx',1,'D2:J112');
Data2 = xlsread('Data.xlsx',2,'D2:J22');
U=Data1(:,1:6)*pi/180;
MM1=Data1(:,7)/1000;
UU=Data2(:,1:6)*pi/180;
VV1=Data2(:,7)/1000;

q1_batch = U(:,1);
q2_batch = U(:,2);
q3_batch = U(:,3);
q4_batch = U(:,4);
q5_batch = U(:,5);
q6_batch = U(:,6);
P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��


F_index=1;
MaxIt=20
nPop=24;
lp=0.001*rands(24,1);
% function [BestX,BestF,HisBestFit]=MRFO(F_index,MaxIt,nPop)

%          [Low,Up,Dim]=FunRange(F_index); 
Low=-0.1;
Up=0.1;
Dim=1;
a_d_alpha_theta0_norm22=...
[ 0.001521274290792
   0.266841301555988
   0.070000000000000
   0.000000000000000
  -0.000000000000001
  -0.006518299457267
   0.290790406698613
   0.002877493764307
   0.002875682158873
   0.301737493820960
   0.000918402652134
   0.072000000000000
  -1.567557607169525
  -0.000057592388932
  -1.570227249116996
   1.571222991304497
  -1.570907296870046
  -0.000000000000000
  -0.000000000000000
  -1.570000000000000
   0.005035008654461
   0.000060750236533
   0.001075101068352
   0.000021771164074];
R32=a_d_alpha_theta0_norm22;
    for i=1:nPop   
        PopPos(i,:)=rand(1,Dim).*(Up-Low);
        PopFit(i)=BenFunctions(PopPos(i,:),F_index,Dim);   
    end
       BestF=inf;
       BestX=[];

    for i=1:nPop
        if PopFit(i)<=BestF
           BestF=PopFit(i);
           BestX=PopPos(i,:);
        end
    end

       HisBestFit=zeros(MaxIt,1);


for It=1:MaxIt  
     Coef=It/MaxIt; 
     
       if rand<0.5
          r1=rand;                         
          Beta=2*exp(r1*((MaxIt-It+1)/MaxIt))*(sin(2*pi*r1));    
          if  Coef>rand                                                      
              newPopPos(1,:)=BestX+rand(1,Dim).*(BestX-PopPos(1,:))+Beta*(BestX-PopPos(1,:)); %Equation (4)
          else
              IndivRand=rand(1,Dim).*(Up-Low)+Low;                                
              newPopPos(1,:)=IndivRand+rand(1,Dim).*(IndivRand-PopPos(1,:))+Beta*(IndivRand-PopPos(1,:)); %Equation (7)         
          end              
       else 
            Alpha=2*rand(1,Dim).*(-log(rand(1,Dim))).^0.5;           
            newPopPos(1,:)=PopPos(1,:)+rand(1,Dim).*(BestX-PopPos(1,:))+Alpha.*(BestX-PopPos(1,:)); %Equation (1)
       end
     
    for i=2:nPop
        if rand<0.5
           r1=rand;                         
           Beta=2*exp(r1*((MaxIt-It+1)/MaxIt))*(sin(2*pi*r1));    
             if  Coef>rand                                                      
                 newPopPos(i,:)=BestX+rand(1,Dim).*(PopPos(i-1,:)-PopPos(i,:))+Beta*(BestX-PopPos(i,:)); %Equation (4)
             else
                 IndivRand=rand(1,Dim).*(Up-Low)+Low;                                
                 newPopPos(i,:)=IndivRand+rand(1,Dim).*(PopPos(i-1,:)-PopPos(i,:))+Beta*(IndivRand-PopPos(i,:));  %Equation (7)       
             end              
        else
            Alpha=2*rand(1,Dim).*(-log(rand(1,Dim))).^0.5;           
            newPopPos(i,:)=PopPos(i,:)+rand(1,Dim).*(PopPos(i-1,:)-PopPos(i,:))+Alpha.*(BestX-PopPos(i,:)); %Equation (1)
       end         
    end
         
           for i=1:nPop        
               newPopPos(i,:)=SpaceBound(newPopPos(i,:),Up,Low);
               newPopFit(i)=BenFunctions(newPopPos(i,:),F_index,Dim);    
              if newPopFit(i)<PopFit(i)
                 PopFit(i)=newPopFit(i);
                 PopPos(i,:)=newPopPos(i,:);
              end
           end
     
            S=2;
        for i=1:nPop           
            newPopPos(i,:)=PopPos(i,:)+S*(rand*BestX-rand*PopPos(i,:)); %Equation (8)
        end
     
     for i=1:nPop        
         newPopPos(i,:)=SpaceBound(newPopPos(i,:),Up,Low);
         newPopFit(i)=BenFunctions(newPopPos(i,:),F_index,Dim);    
         if newPopFit(i)<PopFit(i)
            PopFit(i)=newPopFit(i);
            PopPos(i,:)=newPopPos(i,:);
         end
     end
     
     for i=1:nPop
        if PopFit(i)<BestF
           BestF=PopFit(i);
           BestX=PopPos(i,:);            
        end
     end
 
  
     HisBestFit(It)=BestF;
    fp= fh(PopFit'+a_d_alpha_theta0_norm,Data1); 
    PopFi=R32;
end



%����
q1_batch = U(:,1);
q2_batch = U(:,2);
q3_batch = U(:,3);
q4_batch = U(:,4);
q5_batch = U(:,5);
q6_batch = U(:,6);

MSE=0;
E_max2=0;
%--------
%a_d_alpha_theta0_ex=a_d_alpha_theta0_ex+0.4*rands(24,1);
%neto=zeros(6,1);
for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
%     L_ex11=my_forward(a_d_alpha_theta0_ex,q);
% KK1=neto+q;
    L_ex11=MM1(i);
    L_norm1=my_forward( PopFi,q,P0);
    Error=L_norm1-L_ex11;
    MSE=MSE+(norm(Error))^2;
    E_max2=max((norm(Error))^2,E_max2);
end
%MSE=MSE/length(q1_batch);
%display(['Testing MSE:',num2str(MSE)]);
%display(['Max Error square:',num2str(E_max2)]);
MSE=MSE/length(q1_batch);
RMSE=sqrt(MSE);
E_max2=sqrt(E_max2);
display(['Testing RMSE:',num2str(RMSE)]);
display(['Max Error:',num2str(E_max2)]);

