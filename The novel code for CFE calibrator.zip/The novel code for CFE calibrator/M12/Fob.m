function Few=Fob(x,L_ex11,q1,q2,q3,q4,q5,q6,xyz)


MSE0=0;
    for i = 1:length(q1)
%         x=Sol(:,k);
        q=[q1(i);q2(i);q3(i);q4(i);q5(i);q6(i)];
        L_norm0=my_forward(x,xyz,q);
        L=L_ex11(i);
        Error=L_norm0-L;
        MSE0=MSE0+(norm(Error))^2; 
    end
        MSE0=MSE0/length(q1);
        RMSE_mem=sqrt(MSE0);
        Few=RMSE_mem;
        
    function y=sensory_modality_NEW(x,Ngen)
        y=x+(0.025/(x*Ngen));