 %revision history:
%v1: Feb.5th, 2020,by Shuai Li
%v2: Feb. 11th,2020 by Shuai Li
% clear all
% close all
% tic
%------------------------------------------
%�궨���֣��������ݼ����б궨
%�ⲿ���ǻ�������������pre_processing.m(����matlab���������ȡ���궨��е�۵�foward
%kinematics����Բ����㶯��Jacobian���󣩣�my_forward.m(��pre_processing.m��õ�forward
%kinematics����my_Jacobian.m����pre_processing.m��õ�Jacobian)��
%------------------------------------------
%ϵͳ������������е�۵���ʵ����ֵ���������ֵ��
%����˳��a1,a2,a3,a4,a5,a6,d1,d2,d3,d4,d5,d6,alpha1,alpha2,alpha3,alpha4,alpha5,alpha6,...
%theta0_1,theta0_2,theta0_3,theta0_4,theta0_5,theta0_6;
%a_d_alpha_theta0_xyz_ex=rand(24,1);%[];%�����˵���ʵ����a d alpha theta0

% a_d_alpha_theta0_norm0=...
%     [0 0.27 0.07 0 0 0 ...
%     0.29 0 0 0.302 0 0.072 ...
%     -1.571 0 -1.571 1.571 -1.571 0 ...
%     0 -1.57 0 0 0 0]';
% a_d_alpha_theta0_norm0=...
%     [0.24872627 0.90065082 -0.20466089 0 0 0 ...
%     0.6535 0 0 1.03138548 0 0.2006 ...
%     -1.571 0 1.571 -1.571 1.571 0 ...
%     0 0 0 0 0 0]';
% a_d_alpha_theta0=a_d_alpha_theta0_norm0;
% % 
% % data=xlsread('E:\Data\2000New0.xlsx',1,'A100:G352');
% % data1=xlsread('E:\Data\2000New0.xlsx',1,'A100:G352');
% 
% % data=xlsread('E:\Data\2000New0.xlsx',1,'A300:G502');
% % data1=xlsread('E:\Data\2000New0.xlsx',1,'A300:G502');
% 
% data=xlsread('E:\Data\2000New0.xlsx',4,'A02:G162');
% data1=xlsread('E:\Data\2000New0.xlsx',4,'A162:G206');
% 
% % data=xlsread('E:\Data\2000New0.xlsx',1,'A200:G402');
% % data1=xlsread('E:\Data\2000New0.xlsx',1,'A200:G402');
% 
% % data=xlsread('D:\��ʿѧϰ\������\����\Data1\Data3.xlsx',1,'D2:J250');
% % data1=xlsread('D:\��ʿѧϰ\������\����\Data1\Data3.xlsx',2,'D2:J150');
% %a_d_alpha_theta0_xyz_ex=a_d_alpha_theta0_xyz_norm0;
% q1 = pi/180*data(:,1);
% q2 = pi/180*data(:,2);
% q3 = pi/180*data(:,3);
% q4 = pi/180*data(:,4);
% q5 = pi/180*data(:,5);
% q6= pi/180*data(:,6);
% 
% %----------------------------------------
% 
% xyz0=[1 1 1];
% xyz=xyz0;

%  for iteration=1:N
% %------------------------------------------
% %--------
% delta2=0;
% delta3=0;
% MSE1=0;
% for i = 1:length(q1)
% L_ex11=1/1000*data(:,7);
%    q=[q1(i);q2(i);q3(i);q4(i);q5(i);q6(i)]; 
%    L=[L_ex11(i)];
%    L_norm0=my_forward(a_d_alpha_theta0,xyz,q);
%    J_norm0=my_Jacobian1(a_d_alpha_theta0,xyz,q);
%    Error=L_norm0-L;
%    MSE1=MSE1+(norm(Error))^2;
%    delta2=delta2+J_norm0'*Error;
%    delta3=delta3+J_norm0'*J_norm0;  
%    
% end
%     %Pos1=Pos1-pinv(delta1+0.0004*eye(27))*delta0;
% 
% delta2=delta2/length(q1);
% delta3=delta3/length(q1);
% MSE1=MSE1/length(q1);
% MSE_store1=[MSE_store1;MSE1];
%   xyz=xyz-(pinv(delta3+0.0004*eye(3))*delta2)';
%  
% end
% xyz;
% toc

% xyz=[0.2437 -0.4540 0.0065];
% xyz=[1.62041479809599	0.158195951213015	0.518239071855283];
% xyz=[1.65	0.159	0.518239071855283];
% xyz=[1.64	0.163	0.67];

% L_ex11=1/1000*data(:,7);


 function kk=BFP(Q2)
% Q2=0.001*rands(6,1);

 a_d_alpha_theta0_norm0=...
    [0 0.27 0.07 0 0 0 ...
    0.29 0 0 0.302 0 0.072 ...
    -1.571 0 -1.571 1.571 -1.571 0 ...
    0 -1.57 0 0 0 0]';
%P0=[0.5,-1,1-0.0627]';%�궨��
 %P0=[0.242654051842270 -0.453838756463155 0.007685659149684]';
% P0=[ 0.242 -0.453 0.006]';%Ч����
 P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
%a_d_alpha_theta0_norm=rand(24,1);%[];%�����˵��������a d alpha theta0
a_d_alpha_theta0_norm=a_d_alpha_theta0_norm0;
%a_d_alpha_theta0_ex=a_d_alpha_theta0_norm.*(1+0.05*rands(24,1))+0.05*rands(24,1)+0.1*randn(24,1);
% a_d_alpha_theta0_ex=a_d_alpha_theta0_norm.*(1+0.05*rands(27,1))+0.05*rands(27,1);
%  a_d_alpha_theta0_ex=a_d_alpha_theta0_norm.*(1+0.05*rands(24,1))+0.05*rands(24,1);
%a_d_alpha_theta0_ex=a_d_alpha_theta0_norm0;
Data1 = xlsread('Data.xlsx',1,'D2:J112');
Data2 = xlsread('Data.xlsx',2,'D2:J22');
U=Data1(:,1:6)*pi/180;
MM1=Data1(:,7)/1000;
UU=Data2(:,1:6)*pi/180;
VV1=Data2(:,7)/1000;

q1_batch = U(:,1);
q2_batch = U(:,2);
q3_batch = U(:,3);
q4_batch = U(:,4);
q5_batch = U(:,5);
q6_batch = U(:,6);
% Q2=0.002*rands(6,1);

trace=[];
X=[];

% n is the population size
% N_iter represnets total number of iterations
p=0.8;                       % probabibility switch
power_exponent=0.1;
sensory_modality=0.01;
n=2;
% X=zeros(24,100);
RMSE_mem=0;%����ֵ
mem=X;
Xnew=X;
MaxIt=2; 
Sol=zeros(1,1);
SearchAgents_no=2;
    RMSE_mem_store=[];
for  k=1:n
    
      Sol(:,k) =0.05*rands(1,1);
      x=Q2;
      ww=zeros(18,1);
neto1=[ww;x];


a_d_alpha_theta0_norm2=a_d_alpha_theta0_norm+neto1;
      
      
        Fitness(k)= fh(a_d_alpha_theta0_norm2,Data1);
%         Fob(x,L_ex11,q1,q2,q3,q4,q5,q6,xyz);
%         RMSE_mem_store=[RMSE_mem_store;RMSE_mem];
end
        [fmin,a]=min(Fitness);
        best_pos=Sol(:,a);
        S=Sol;
        
        
for t=1:MaxIt

for  k=1:n
    
        x=S(:,k);
        
         x=Q2;
      ww=zeros(18,1);
neto1=[ww;x];


a_d_alpha_theta0_norm2=a_d_alpha_theta0_norm+neto1;
        Fnew=fh(a_d_alpha_theta0_norm2,Data1);
        
%         Fob(x,L_ex11,q1,q2,q3,q4,q5,q6,xyz);
        FP=(sensory_modality*(Fnew^power_exponent));   
        %Global or local search
          if rand<p    
            dis = rand * rand * best_pos - Sol(:,k);        %Eq. (2) in paper
            S(:,k)=Sol(:,k)+dis*FP;
            
           else
              % Find random butterflies in the neighbourhood
              epsilon=rand;
              JK=randperm(n);
             
              dis=epsilon*epsilon*Sol(:,JK(1))-Sol(:,JK(2));
              S(:,k)=Sol(:,k)+dis*FP;                         %Eq. (3) in paper
          end
         x=S(:,k);
         x=Q2;
      ww=zeros(18,1);
neto1=[ww;x];


a_d_alpha_theta0_norm2=a_d_alpha_theta0_norm+neto1;
         Fnew=fh(a_d_alpha_theta0_norm2,Data1); 
          
         if (Fnew<=Fitness(k))
             Sol(:,k)=S(:,k);
             Fitness(k)=Fnew;
         end
         if Fnew<=fmin
             best_pos=S(:,k);
             fmin=Fnew;
         end
   
end
        sensory_modality=sensory_modality_NEW(sensory_modality, MaxIt);
%         a_d_alpha_theta0=a_d_alpha_theta0_norm0+best_pos;
       kk=best_pos;
%         a_d_alpha_theta0=x;
        trace=[trace;fmin];
end
kk=best_pos;



