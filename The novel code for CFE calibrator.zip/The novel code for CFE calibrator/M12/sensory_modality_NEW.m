
        
    function y=sensory_modality_NEW(x,Ngen)
        y=x+(0.025/(x*Ngen));