% ����������
% ��������
%%��ջ�������  
clc
clear
Train=xlsread('train_q.xlsx');
x_in=Train*pi/180;
L_train=xlsread('train_L.xlsx');
L_train=L_train/1000;
Test=xlsread('test_q.xlsx');
x_in_t=Test*pi/180;
L_t=xlsread('test_L.xlsx');
L_t=L_t/1000;
x_train=x_in';
y_train=L_train';
x_test=x_in_t';
y_test=L_t';

% ѵ������
a_d_alpha_theta0_norm0=...
    [0 0.27 0.07 0 0 0 ...
    0.29 0 0 0.302 0 0.072 ...
    -1.571 0 -1.571 1.571 -1.571 0 ...
    0 -1.57 0 0 0 0]';
P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
tic
% [out_put,L]=mytrain(x_train,y_train,a_d_alpha_theta0_norm0,P0);
[out_put,L]=mytrain_tanh(x_train,y_train,a_d_alpha_theta0_norm0,P0);
ANN_tahnmse = xlswrite('___ANN_tanhmse.xlsx', L);

%��������
% out_put
a=eye(18,1);
delta_w=cat(1,a,out_put);
delta_w(1)=0;
% gol=a_d_alpha_theta0_norm0+delta_w
MSE=0;
E_max2=0;
Err_store=0;
%--------
%a_d_alpha_theta0_ex=a_d_alpha_theta0_ex+0.4*rands(24,1);
%neto=zeros(6,1);
for i = 1:length(y_test)%each i represent one measurement
    x=x_test(:,i);
%     L_ex11=my_forward(a_d_alpha_theta0_ex,q);
    KK1=out_put+x;
    L_ex11=y_test(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm0,KK1,P0);
    Error=L_norm1-L_ex11;
    Err_store=Err_store+norm(Error);
    MSE=MSE+(norm(Error))^2;
    E_max2=max((norm(Error))^2,E_max2);
end
%display(['Max Error square:',num2str(E_max2)]);
MSE=MSE/length(y_test);
Err_store=Err_store/length(y_test);
RMSE=sqrt(MSE);
E_max2=sqrt(E_max2);
display(['Testing MSE:',num2str(MSE)]);
display(['Testing MEAN:',num2str(Err_store)]);
display(['Testing RMSE:',num2str(RMSE)]);
display(['Max Error:',num2str(E_max2)]);
toc
Err_store=zeros(0,1);
for i = 1:length(y_train)%each i represent one measurement
    x=x_train(:,i);
%     L_ex11=my_forward(a_d_alpha_theta0_ex,q);
    KK1=out_put+x;
    L_ex11=y_train(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm0,KK1,P0);
    Error=L_norm1-L_ex11;
    Err_store=[Err_store;norm(Error)];
end
% plot(Err_store);
ANN_tahnError = xlswrite('___ANN_tanhError.xlsx', Err_store);