%revision history:
%v1: Feb.5th, 2020,by Shuai Li
%v2: Feb. 11th,2020 by Shuai Li
clear all
close all
tic
%------------------------------------------
%�궨���֣��������ݼ����б궨
%�ⲿ���ǻ�������������pre_processing.m(����matlab���������ȡ���궨��е�۵�foward
%kinematics����Բ����㶯��Jacobian���󣩣�my_forward.m(��pre_processing.m��õ�forward
%kinematics����my_Jacobian.m����pre_processing.m��õ�Jacobian)��
%------------------------------------------
%ϵͳ������������е�۵���ʵ����ֵ���������ֵ��
%����˳��a1,a2,a3,a4,a5,a6,d1,d2,d3,d4,d5,d6,alpha1,alpha2,alpha3,alpha4,alpha5,alpha6,...
%theta0_1,theta0_2,theta0_3,theta0_4,theta0_5,theta0_6;
%a_d_alpha_theta0_ex=rand(24,1);%[];%�����˵���ʵ����a d alpha theta0
%     a_d_alpha_theta0_norm0=...
%     [0 0.4318 0.0203 0 0 0 ...
%     0 0 0.15 0.4318 0 0 ...
%     1.571 0 -1.571 1.571 -1.571 0 ...
%     0 0 0 0 0 0 ...
%     1,1.3,1.2]';

Data1 = xlsread('Data.xlsx',1,'D2:J112');
Data2 = xlsread('Data.xlsx',2,'D2:J22');
U=Data1(:,1:6)*pi/180;
MM1=Data1(:,7)/1000;
% UU=Data2(:,1:6)*pi/180;
% VV1=Data2(:,7)/1000;
DH1=...
     [0.000106673161480
   0.269588482882252
   0.069570339837035
  -0.000411662270119
  -0.000179526076127
   0.000002877509668
   0.289627546060358
   0.000031066110962
   0.000031066887493
   0.301934514740830
   0.000131491253966
   0.072380770212227
  -1.571016528217303
   0.000010556290893
  -1.570991236634694
   1.571002832136982
  -1.570990529221606
  -0.000000000000000
   0.000009694355989
  -1.569839764563451
   0.000138406952279
   0.000009077164228
   0.000012959781740
  -0.000000005017305];
DH2=...
     [0.000200073263211
   0.269285208467107
   0.070000000000000
                   0
                   0
   0.000212909094291
   0.289232667400681
   0.000053392318996
   0.000053388667881
   0.302226285451036
   0.000248086569114
   0.072000000000000
  -1.571002786475299
   0.000023680506692
  -1.570978631255746
   1.571004911438453
  -1.570982184072991
                   0
                   0
  -1.570000000000000
   0.000243585771499
   0.000017043830438
  -0.000001748350194
  -0.000000012929301];
DH3=...
     [-0.00131345829047206
0.269309123878234
0.0697084056641824
-0.000241236235807545
0.000116652477496651
-0.00105085477730982
0.289314556685929
-0.000204682216714734
-0.000592916252102009
0.300838719683844
-0.000503401180187084
0.0724402741966926
-1.57128226401335
8.93140040880154e-05
-1.57013411337932
1.57016416346986
-1.57070357372679
0.000662807589513917
0.000550280107386789
-1.56900876020643
-0.000290536778815294
0.000391789810400590
0.000429419069679910
-6.95127760921776e-05];
DH4=...
     [-0.003544680574327
   0.269677857928149
   0.070076525442273
   0.000035954797466
  -0.000157631987001
  -0.000044124086936
   0.290095310375795
  -0.000180200150986
   0.000025291352522
   0.301972445219093
  -0.000004162924009
   0.072004648921874
  -1.570902323364732
   0.000014829836949
  -1.570734625007067
   1.571660441130738
  -1.571008405588589
  -0.000107833258836
   0.000249878611152
  -1.569168372626613
   0.008425424305972
  -0.002814444193507
   0.000466814076836
  -0.001790419098562];
DH5=...
     [0
   0.270000000000000
   0.070000000000000
                   0
                   0
                   0
   0.290000000000000
                   0
                   0
   0.302000000000000
                   0
   0.072000000000000
  -1.571000000000000
                   0
  -1.571000000000000
   1.571000000000000
  -1.571000000000000
                   0
   0.001952212683001
  -1.567951944176339
   0.002096967598019
   0.002167461535692
   0.001120594859269
   0.002064042464999];
DH6=...
     [-0.001200702558141
   0.268921291312879
   0.069708405664182
  -0.000241236235808
   0.000116652477497
  -0.000936730700239
   0.288899476149239
  -0.000178275393127
  -0.000566527175238
   0.300963714562224
  -0.000371616667786
   0.072440274196693
  -1.571282629679591
   0.000101723193765
  -1.570123181937280
   1.570166907031870
  -1.570693705244220
   0.000662807589514
   0.000550280107387
  -1.569008760206430
  -0.000159375622921
   0.000401492854602
   0.000428108276514
  -0.000069441778954];
DH7=...
     [ -0.003073666106636
   0.269167867153142
   0.070115895920683
   0.000054711137007
  -0.000622248035073
  -0.000408589822607
   0.290319903678358
  -0.000211645790043
  -0.000006152727093
   0.301763240330856
  -0.000061781833037
   0.071948941958027
  -1.570982185868304
   0.000002132070292
  -1.570745609345939
   1.571667939879298
  -1.571012607206551
  -0.000107833258836
   0.000189598588891
  -1.569418600426781
   0.008432897168677
  -0.002820410836836
   0.000500211629761
  -0.001790301400879];
DH8=...
     [-0.003544680574327
   0.269677857928149
   0.070076525442273
   0.000035954797466
  -0.000157631987001
  -0.000044124086936
   0.290095310375795
  -0.000180200150986
   0.000025291352522
   0.301972445219093
  -0.000004162924009
   0.072004648921874
  -1.570902323364732
   0.000014829836949
  -1.570734625007067
   1.571660441130738
  -1.571008405588589
  -0.000107833258836
   0.000092056253013
  -1.569388795153862
   0.008229134034377
  -0.002985748953305
   0.000368966710747
  -0.001977814523413];
n=1;
omega1=1.9279;
omega2=2.0457;
omega3=2.2782;
omega4=1.6672;
omega5=3.5078;
omega6=2.7307;
omega7=5.3702;
omega8=4.1460;
omega=0;
KK=0;
KM=0;

%ģ��PID������ʼ��
deg1 = 0.0;
deg2 = 0.0;%�����ȳ�ʼ��

%kp,ki,kd��ʼ��
c1 = 0.49;
c2 = 0.50;
c3 = 0.51;
c4 = 0.52;
c5 = 0.53;
c6 = 0.54;
c7 = 0.55;
%ģ��1		
pc1 = 1.6;
pc2 = 1.7;
pc3 = 1.8;
pc4 = 1.9;
pc5 = 2.0;
pc6 = 2.1;
pc7 = 2.2;
% %ģ��2
% ic1 = 1.6;
% ic2 = 1.7;
% ic3 = 1.8;
% ic4 = 1.9;
% ic5 = 2.0;
% ic6 = 2.1;
% ic7 = 2.2;
%ģ��2
ic1 = 1.5;
ic2 = 1.6;
ic3 = 1.7;
ic4 = 1.8;
ic5 = 1.9;
ic6 = 2.0;
ic7 = 2.1;



%ģ��3
dc1 = 1.8;
dc2 = 1.9;
dc3 = 2.0;
dc4 = 2.1;
dc5 = 2.2;
dc6 = 2.3;
dc7 = 2.4;


%ģ��4
ec1 = 1.0;
ec2 = 1.2;
ec3 = 1.4;
ec4 = 1.6;
ec5 = 1.8;
ec6 = 2.0;
ec7 = 2.2;


% %ģ��5
% fc1 = 3.0;
% fc2 = 3.2;
% fc3 = 3.4;
% fc4 = 3.6;
% fc5 = 3.8;
% fc6 = 4;
% fc7 = 4.2;

%ģ��5
fc1 = 3.1;
fc2 = 3.2;
fc3 = 3.3;
fc4 = 3.4;
fc5 = 3.5;
fc6 = 3.6;
fc7 = 3.7;

%ģ��6
gc1 = 2.2;
gc2 = 2.4;
gc3 = 2.6;
gc4 = 2.8;
gc5 = 3.0;
gc6 = 3.2;
gc7 = 3.4;



% %ģ��7
% hc1 = 4.6;
% hc2 = 4.8;
% hc3 = 5;
% hc4 = 5.2;
% hc5 = 5.4;
% hc6 = 5.6;
% hc7 = 5.8;


%ģ��7

% hc1 = 12.1;
% hc2 = 12.3;
% hc3 = 12.5;
% hc4 = 12.7;
% hc5 = 12.9;
% hc6 = 13.1;
% hc7 = 13.3;
hc1 = 13.1;
hc2 = 13.3;
hc3 = 13.5;
hc4 = 13.7;
hc5 = 13.9;
hc6 = 14.1;
hc7 = 14.3;

% %ģ��8
% jc1 = 3.6;
% jc2 = 3.8;
% jc3 = 4.0;
% jc4 = 4.2;
% jc5 = 4.4;
% jc6 = 4.6;
% jc7 = 4.8;
%ģ��8
jc1 = 4;
jc2 = 4.1;
jc3 = 4.2;
jc4 = 4.3;
jc5 = 4.4;
jc6 = 4.5;
jc7 = 4.6;

% jc1 = 4.2;
% jc2 = 4.3;
% jc3 = 4.4;
% jc4 = 4.5;
% jc5 = 4.6;
% jc6 = 4.7;
% jc7 = 4.8;

Iter=100;

%ģ��PID��ʼ�����

curErr = 0;
RMSE_store=zeros(0,1);


for iteration=1:Iter
omega=omega1+omega2+omega3+omega4+omega5+omega6+omega7+omega8;
    a_d_alpha_theta0_norm=(omega1*DH1+omega2*DH2+omega3*DH3+omega4*DH4+omega5*DH5+omega6*DH6+omega7*DH7+omega8*DH8)/omega;
    
curErr = fh(a_d_alpha_theta0_norm,Data1);
RMSE_store=[RMSE_store;curErr];
    
   if curErr >= c7 
deg1 = 1; 
deg2 = 0;
omega1 = outFuzzy(deg1, pc7, deg2, 0);
omega2 = outFuzzy(deg1, ic7, deg2, 0);
omega3 = outFuzzy(deg1, dc7, deg2, 0);
omega4 = outFuzzy(deg1, ec7, deg2, 0);
omega5 = outFuzzy(deg1, fc7, deg2, 0);
omega6 = outFuzzy(deg1, gc7, deg2, 0);
omega7 = outFuzzy(deg1, hc7, deg2, 0);
omega8 = outFuzzy(deg1, jc7, deg2, 0);

				
elseif curErr < c7 && curErr >= c6
deg1 = (c7 - curErr) / (c7 - c6);
deg2 = (curErr - c6) / (c7 - c6);
omega1 = outFuzzy(deg1, pc6, deg2, pc7);
omega2 = outFuzzy(deg1, ic6, deg2, ic7);
omega3 = outFuzzy(deg1, dc6, deg2, dc7);
omega4 = outFuzzy(deg1, ec6, deg2, ec7);
omega5 = outFuzzy(deg1, fc6, deg2, fc7);
omega6 = outFuzzy(deg1, gc6, deg2, gc7);
omega7 = outFuzzy(deg1, hc6, deg2, hc7);
omega8 = outFuzzy(deg1, jc6, deg2, jc7);


				
elseif curErr < c6 && curErr >= c5 
deg1 = (c6 - curErr) / (c6 - c5);
deg2 = (curErr - c5) / (c6 - c5);
omega1 = outFuzzy(deg1, pc5, deg2, pc6);
omega2 = outFuzzy(deg1, ic5, deg2, ic6);
omega3 = outFuzzy(deg1, dc5, deg2, dc6);
omega4 = outFuzzy(deg1, ec5, deg2, ec6);
omega5 = outFuzzy(deg1, fc5, deg2, fc6);
omega6 = outFuzzy(deg1, gc5, deg2, gc6);
omega7 = outFuzzy(deg1, hc5, deg2, hc6);
omega8 = outFuzzy(deg1, jc5, deg2, jc6);

				
elseif curErr < c5 && curErr >= c4 
deg1 = (c5 - curErr) / (c5 - c4);
deg2 = (curErr - c4) / (c5 - c4);
omega1 = outFuzzy(deg1, pc4, deg2, pc5);
omega2 = outFuzzy(deg1, ic4, deg2, ic5);
omega3 = outFuzzy(deg1, dc4, deg2, dc5);
omega4 = outFuzzy(deg1, ec4, deg2, ec5);
omega5 = outFuzzy(deg1, fc4, deg2, fc5);
omega6 = outFuzzy(deg1, gc4, deg2, gc5);
omega7 = outFuzzy(deg1, hc4, deg2, hc5);
omega8 = outFuzzy(deg1, jc4, deg2, jc5);


				
elseif curErr < c4 && curErr >= c3
deg1 = (c4 - curErr) / (c4 - c3);
deg2 = (curErr - c3) / (c4 - c3);
omega1 = outFuzzy(deg1, pc3, deg2, pc4);
omega2 = outFuzzy(deg1, ic3, deg2, ic4);
omega3 = outFuzzy(deg1, dc3, deg2, dc4);
omega4 = outFuzzy(deg1, ec3, deg2, ec4);
omega5 = outFuzzy(deg1, fc3, deg2, fc4);
omega6 = outFuzzy(deg1, gc3, deg2, gc4);
omega7 = outFuzzy(deg1, hc3, deg2, hc4);
omega8 = outFuzzy(deg1, jc3, deg2, jc4);


elseif curErr < c3 && curErr >= c2
deg1 = (c3 - curErr) / (c3 - c2);
deg2 = (curErr - c2) / (c3 - c2);
omega1 = outFuzzy(deg1, pc2, deg2, pc3);
omega2 = outFuzzy(deg1, ic2, deg2, ic3);
omega3 = outFuzzy(deg1, dc2, deg2, dc3);
omega4 = outFuzzy(deg1, ec2, deg2, ec3);
omega5 = outFuzzy(deg1, fc2, deg2, fc3);
omega6 = outFuzzy(deg1, gc2, deg2, gc3);
omega7 = outFuzzy(deg1, hc2, deg2, hc3);
omega8 = outFuzzy(deg1, jc2, deg2, jc3);
				
elseif curErr < c2 && curErr >= c1 
deg1 = (c2 - curErr) / (c2 - c1);
deg2 = (curErr - c1) / (c2 - c1);
omega1 = outFuzzy(deg1, pc1, deg2, pc2);
omega2 = outFuzzy(deg1, ic1, deg2, ic2);
omega3 = outFuzzy(deg1, dc1, deg2, dc2);
omega4 = outFuzzy(deg1, ec1, deg2, ec2);
omega5 = outFuzzy(deg1, fc1, deg2, fc2);
omega6 = outFuzzy(deg1, gc1, deg2, gc2);
omega7 = outFuzzy(deg1, hc1, deg2, hc2);
omega8 = outFuzzy(deg1, jc1, deg2, jc2);


				
elseif curErr < c1 
				deg1 = 1;
				deg2 = 0;
				omega1 = outFuzzy(deg1, pc1, deg2, 0);
				omega2 = outFuzzy(deg1, ic1, deg2, 0);
				omega3 = outFuzzy(deg1, dc1, deg2, 0); 
                omega4 = outFuzzy(deg1, ec1, deg2, 0);
				omega5 = outFuzzy(deg1, fc1, deg2, 0);
				omega6 = outFuzzy(deg1, gc1, deg2, 0);   
                omega7 = outFuzzy(deg1, hc1, deg2, 0);
				omega8 = outFuzzy(deg1, jc1, deg2, 0);
				  
    end
     
    
    

end

% omega11=boosting1();%L1����
%     K1=omega11(1,1);
%     K11=omega11(2:25,:);
%     
%  omega22=boosting2();%L2����
%     K2=omega22(1,1);
%     K22=omega22(2:25,:);
%     
%     omega33=boosting3();%Elastic����
%     K3=omega33(1,1);
%     K33=omega33(2:25,:);
%     
%      omega44=boosting4();%Dropout����
%     K4=omega44(1,1);
%     K44=omega44(2:25,:);
%     
%        omega55=boosting5();%log����
%     K5=omega55(1,1);
%     K55=omega55(2:25,:);
%     
%        omega66=boosting6();%swish����
%     K6=omega66(1,1);
%     K66=omega66(2:25,:);

% omega122=boosting12();%L1����
% 
% K1=omega122(1,1);
%     K11=omega122(9:32,:);
%     K11=K1*K11;
%     
%     K2=omega122(2,1);
%     K22=omega122(33:56,:);
%     K22=K2*K22;
%    
%     K3=omega122(3,1);
%     K33=omega122(57:80,:);
%     K33=K3*K33;
%      
%     K4=omega122(4,1);
%     K44=omega122(81:104,:);
%     K44=K4*K44;
%     
%     K5=omega122(5,1);
%     K55=omega122(105:128,:);
%     K55=K5*K55;
%       
%     K6=omega122(6,1);
%     K66=omega122(129:152,:);
%     K66=K6*K66;
%     
%      K7=omega122(7,1);
%     K77=omega122(153:176,:);
%     K77=K7*K77;
%       
%     K8=omega122(8,1);
%     K88=omega122(177:200,:);
%     K88=K8*K88;
% 
%     
% for i= 1:n
%     
%     omega1=omega1+K1;
%     
% end
% 
% for i= 1:n
%     
%     omega2=omega2+K2;
% end
% 
% for i= 1:n
%     
%     omega3=omega3+K3;
% end
% for i= 1:n
%     
%     omega4=omega4+K4;
% end
% 
% for i= 1:n
%     
%     omega5=omega5+K5;
% end
% 
% for i= 1:n
%     
%     omega6=omega6+K6;
% end
% 
% for i= 1:n
%     
%     omega7=omega7+K7;
% end
% 
% for i= 1:n
%     
%     omega8=omega8+K8;
% end
% 
% % omega=omega1+omega2;%L1+L2
% % KK=K11+K22;
% 
% % omega=omega1+omega2+omega3;%L1+L2+Elastic
% % KK=K11+K22+K33;
% 
% % omega=omega1+omega2+omega3+omega4;%L1+L2+Elastic+Dropout
% % KK=K11+K22+K33+K44;
% 
% % omega=omega1+omega2+omega3+omega4+omega5;%L1+L2+Elastic+Dropout+log
% % KK=K11+K22+K33+K44+K55;
% 
% % omega=omega1+omega2+omega3+omega4+omega5+omega6;%L1+L2+Elastic+Dropout+log+swish
% % KK=K11+K22+K33+K44+K55+K66;
% 
% % omega=omega6+omega4;%M4+����
% % KK=K66+K44;
% 
% omega=omega1+omega2+omega3+omega4+omega5+omega6+omega7+omega8;%L1+L2+Elastic+Dropout+log+swish
% KK=K11+K22+K33+K44+K55+K66+K77+K88;
% 
% 
% 
% KM=KK/omega;
% a_d_alpha_theta0_norm=KM;

toc

P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
format long
figure(1),clf(1),
semilogy(RMSE_store,'rx-')
xlabel('Iteration');
ylabel('RMSE');
display('Calibrated Parameters:');
a_d_alpha_theta0_norm

%  a_d_alpha_theta0_norm0=...
%      [0 0.27 0.07 0 0 0 ...
%     0.29 0 0 0.302 0 0.072 ...
%     -1.571 0 -1.571 1.571 -1.571 0 ...
%     0 -1.57 0 0 0 0]';
% %a_d_alpha_theta0_norm=rand(24,1);%[];%�����˵��������a d alpha theta0
% a_d_alpha_theta0_norm=a_d_alpha_theta0_norm0;
% % a_d_alpha_theta0_ex=a_d_alpha_theta0_norm.*(1+0.01*rands(24,1));
% % %a_d_alpha_theta0_ex=a_d_alpha_theta0_norm0;
% % q1_batch = pi/2*rands(30,1);
% % q2_batch = pi/2*rands(30,1);
% % q3_batch = pi/2*rands(30,1);
% % q4_batch = pi/2*rands(30,1);
% % q5_batch = pi/2*rands(30,1);
% % q6_batch = pi/2*rands(30,1);
% Data1 = xlsread('Data.xlsx',1,'D2:J112');
% Data2 = xlsread('Data.xlsx',2,'D2:J22');
% U=Data1(:,1:6)*pi/180;
% MM1=Data1(:,7)/1000;
% UU=Data2(:,1:6)*pi/180;
% VV1=Data2(:,7)/1000;
% 
% q1_batch = U(:,1);
% q2_batch = U(:,2);
% q3_batch = U(:,3);
% q4_batch = U(:,4);
% q5_batch = U(:,5);
% q6_batch = U(:,6);
% 
% %------------------------------------------%------------------------------------------
% %------------------------------------------%------------------------------------------
% Iter=100;
% MSE_store=zeros(0,1);
% K1=1e-7;
% v=0.00005*rands(1,1);
% % P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
% P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
% % KH1=0.0004;
% KH1=1e-5;
% b=0.00001*rands(24,1);
% 
% for iteration=1:Iter
% %------------------------------------------
% %--------
% delta0=0;
% delta1=0;
% MSE=0;
% 
% %--------
% for i = 1:length(q1_batch)%each i represent one measurement
%     q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
%     %L_ex11=my_forward(a_d_alpha_theta0_ex,q,P0);
%     L_ex11=MM1(i);
%     L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
%     J_norm1=my_Jacobian(a_d_alpha_theta0_norm,q,P0);
%     Error=L_norm1-L_ex11;
%     MSE=MSE+(norm(Error))^2;
%     delta0=delta0+J_norm1'*Error;
%     delta1=delta1+J_norm1'*J_norm1;
%   
% end
% delta0=delta0/length(q1_batch);
% delta1=delta1/length(q1_batch);
% MSE=MSE/length(q1_batch);
% MSE_store=[MSE_store;MSE];
% %a_d_alpha_theta0_ex=a_d_alpha_theta0_ex+0.4*rands(24,1);
% %%%-------------
% %Put your algorithm here
% %Method 1: gradient
% %a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-0.5*delta0;
% %%%-------------
% %Method 2: recursive least square
% %a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-inv(delta1+0.0004*eye(24))*delta0;
% %  a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-pinv(delta1+0.0004*eye(27))*delta0;
% % a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-pinv(delta1)*delta0+0.0001*sign(a_d_alpha_theta0_norm);%��һ�ַ���
% %a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-pinv(delta1)*(delta0+K1*sign(a_d_alpha_theta0_norm));%�ڶ��ּ����򻯷���
% 
%  %a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-pinv(delta1+KH1*eye(24))*(delta0+K1*( a_d_alpha_theta0_norm+a_d_alpha_theta0_norm*exp(-b'* a_d_alpha_theta0_norm)+((b'*a_d_alpha_theta0_norm)*a_d_alpha_theta0_norm')'*exp(-b'* a_d_alpha_theta0_norm))*pinv((1+exp(-b'* a_d_alpha_theta0_norm))^3));
% 
% a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-pinv(delta1+KH1*eye(24))*(delta0+K1*a_d_alpha_theta0_norm*pinv(sqrt(a_d_alpha_theta0_norm'*a_d_alpha_theta0_norm+v)));%��3�ּ����򻯷���
%  
%  %a_d_alpha_theta0_norm=a_d_alpha_theta0_norm-pinv(delta1+KH1*eye(24))*delta0;
% 
% end 
% toc
% %------------------------------------------
% %���ݿ��ӻ�data visualization
% %------------------------------------------
% format long
% figure(1),clf(1),
% semilogy(MSE_store,'rx-')
% xlabel('Iteration');
% ylabel('MSE');
% %display('Calibration Error:');
% %a_d_alpha_theta0_norm-a_d_alpha_theta0_ex
% display('Calibrated Parameters:');
% a_d_alpha_theta0_norm
%------------------------------------------
%���Բ��֣������µ����ݼ����Ա궨Ч��
%------------------------------------------
%the above can be viewed as training from machine learning perspective
%the following is testing
% q=rands(6,1);
% L_ex11=my_forward(a_d_alpha_theta0_ex,q,P0);
q11=[-67.7	24.7	-14.5	-14.9	75.1	-54.4];
q=q11*pi/180;
%L_ex11=my_forward(a_d_alpha_theta0_ex,q);
L_ex11=0.4845;
L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
J_norm1=my_Jacobian(a_d_alpha_theta0_norm,q,P0);
Error=L_norm1-L_ex11;
display(['Position error:',num2str(Error')]);
%testing data batch
% q1_batch = pi*rands(50,1);
% q2_batch = pi*rands(50,1);
% q3_batch = pi*rands(50,1);
% q4_batch = pi*rands(50,1);
% q5_batch = pi*rands(50,1);
% q6_batch = pi*rands(50,1);


q1_batch = U(:,1);
q2_batch = U(:,2);
q3_batch = U(:,3);
q4_batch = U(:,4);
q5_batch = U(:,5);
q6_batch = U(:,6);

MSE=0;
E_max2=0;
%--------

for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
    %L_ex11=my_forward(a_d_alpha_theta0_ex,q,P0);
    %L_ex11=L_ex1(i);
    L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
    Error=L_norm1-L_ex11;
    MSE=MSE+(norm(Error))^2;
    E_max2=max((norm(Error))^2,E_max2);
end
%MSE=MSE/length(q1_batch);
%display(['Testing MSE:',num2str(MSE)]);
%display(['Max Error square:',num2str(E_max2)]);
MSE=MSE/length(q1_batch);
RMSE=sqrt(MSE);
E_max2=sqrt(E_max2);
display(['Testing RMSE:',num2str(RMSE)]);
display(['Max Error:',num2str(E_max2)]);
