function omega22=boosting12()%LMģ��
%LMģ��
% a_d_alpha_theta0_norm0=...
%      [0 0.27 0.07 0 0 0 ...
%     0.29 0 0 0.302 0 0.072 ...
%     -1.571 0 -1.571 1.571 -1.571 0 ...
%     0 -1.57 0 0 0 0]';
% a_d_alpha_theta0_norm0=...
%      [0.001688355373466
%    0.271414139144135
%    0.068646670594044
%   -0.005963257711636
%   -0.009379671811400
%   -0.002797483318012
%    0.303855651245234
%    0.003160702215230
%    0.003166119057148
%    0.310977930182766
%   -0.003851348447716
%    0.078930092751450
%   -1.572036729971958
%   -0.001603553877797
%   -1.570094608682815
%    1.571124557610152
%   -1.571298284628279
%    0.000000000000000
%    0.011350886919732
%   -1.565658718867375
%    0.001570923056250
%   -0.000298818501728
%    0.000621330844209
%    0.000006605504706];
a_d_alpha_theta0_norm0=...
     [0.000106673161480
   0.269588482882252
   0.069570339837035
  -0.000411662270119
  -0.000179526076127
   0.000002877509668
   0.289627546060358
   0.000031066110962
   0.000031066887493
   0.301934514740830
   0.000131491253966
   0.072380770212227
  -1.571016528217303
   0.000010556290893
  -1.570991236634694
   1.571002832136982
  -1.570990529221606
  -0.000000000000000
   0.000009694355989
  -1.569839764563451
   0.000138406952279
   0.000009077164228
   0.000012959781740
  -0.000000005017305];
%a_d_alpha_theta0_norm=rand(24,1);%[];%�����˵��������a d alpha theta0
a_d_alpha_theta0_norm=a_d_alpha_theta0_norm0;
% a_d_alpha_theta0_ex=a_d_alpha_theta0_norm.*(1+0.01*rands(24,1));
% %a_d_alpha_theta0_ex=a_d_alpha_theta0_norm0;
% q1_batch = pi/2*rands(30,1);
% q2_batch = pi/2*rands(30,1);
% q3_batch = pi/2*rands(30,1);
% q4_batch = pi/2*rands(30,1);
% q5_batch = pi/2*rands(30,1);
% q6_batch = pi/2*rands(30,1);
Data1 = xlsread('Data.xlsx',1,'D2:J112');
Data2 = xlsread('Data.xlsx',2,'D2:J22');
U=Data1(:,1:6)*pi/180;
MM1=Data1(:,7)/1000;
UU=Data2(:,1:6)*pi/180;
VV1=Data2(:,7)/1000;

q1_batch = U(:,1);
q2_batch = U(:,2);
q3_batch = U(:,3);
q4_batch = U(:,4);
q5_batch = U(:,5);
q6_batch = U(:,6);
N=length(q1_batch);
%------------------------------------------%------------------------------------------
%------------------------------------------%------------------------------------------
Iter=5;
MSE_store=zeros(0,1);
K1=1e-6;
v=0.001*rands(1,1);
% P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
% KH1=0.0004;
KH1=1e-4;
b=0.001*rands(24,1);


%double ratingHat;
		 omega = 0;
		 err = 0;
		 miu = 0;
		 sigma1 = 0;
		sample_count = 0;
		 phi =0;
		 a = 1;
		 D = 0;
       % dWeight=zeros(N,1)+1/N ;
       dWeight=(ones(N,1)/N)';
        
%	ArrayList<RTuple> error_set = new ArrayList<>();
for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
    L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
err=abs(L_norm1-L_ex11);
miu =miu+ err;
sigma1=sigma1+ err.^2;
sample_count=sample_count+1;
end
%dWeight=1/sample_count;
miu = miu / sample_count;
sigma1 =sqrt(sigma1 / sample_count - miu.^2);
for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
 L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
    err=abs(L_norm1-L_ex11);
    if ((err - miu) > a * sigma1)
        phi=phi+dWeight(i);
    end
end
for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
 L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
    err=abs(L_norm1-L_ex11);
%     if ((err - miu) <= a * sigma1)
 if ((err - miu) > a * sigma1)
        dWeight(i)=dWeight(i)* phi;
    end
    D =D +dWeight(i);
end
for i = 1:length(q1_batch)%each i represent one measurement
dWeight(i)=dWeight(i)/D;
end
omega =log(1 / phi);

% a_d_alpha_theta0_norm=a_d_alpha_theta0_norm*omega;
% % a_d_alpha_theta0_norm1=zeros(24,1);
% % for i = 1:length(q1_batch)%each i represent one measurement
% %     q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
% %     a_d_alpha_theta0_norm1=a_d_alpha_theta0_norm1+a_d_alpha_theta0_norm*omega;
% % end
% omega1=[omega;a_d_alpha_theta0_norm];
omega1=omega;
KK1=a_d_alpha_theta0_norm;

%EKFģ��
a_d_alpha_theta0_norm0=...
     [0.000200073263211
   0.269285208467107
   0.070000000000000
                   0
                   0
   0.000212909094291
   0.289232667400681
   0.000053392318996
   0.000053388667881
   0.302226285451036
   0.000248086569114
   0.072000000000000
  -1.571002786475299
   0.000023680506692
  -1.570978631255746
   1.571004911438453
  -1.570982184072991
                   0
                   0
  -1.570000000000000
   0.000243585771499
   0.000017043830438
  -0.000001748350194
  -0.000000012929301];
%a_d_alpha_theta0_norm=rand(24,1);%[];%�����˵��������a d alpha theta0
a_d_alpha_theta0_norm=a_d_alpha_theta0_norm0;
% a_d_alpha_theta0_ex=a_d_alpha_theta0_norm.*(1+0.01*rands(24,1));
% %a_d_alpha_theta0_ex=a_d_alpha_theta0_norm0;
% q1_batch = pi/2*rands(30,1);
% q2_batch = pi/2*rands(30,1);
% q3_batch = pi/2*rands(30,1);
% q4_batch = pi/2*rands(30,1);
% q5_batch = pi/2*rands(30,1);
% q6_batch = pi/2*rands(30,1);
Data1 = xlsread('Data.xlsx',1,'D2:J112');
Data2 = xlsread('Data.xlsx',2,'D2:J22');
U=Data1(:,1:6)*pi/180;
MM1=Data1(:,7)/1000;
UU=Data2(:,1:6)*pi/180;
VV1=Data2(:,7)/1000;

q1_batch = U(:,1);
q2_batch = U(:,2);
q3_batch = U(:,3);
q4_batch = U(:,4);
q5_batch = U(:,5);
q6_batch = U(:,6);
N=length(q1_batch);
%------------------------------------------%------------------------------------------
%------------------------------------------%------------------------------------------
Iter=5;
MSE_store=zeros(0,1);
K1=1e-7;
v=0.001*rands(1,1);
% P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
% KH1=0.0004;
%KH1=1e-4;
KH1=1e-4;
b=0.001*rands(24,1);



%double ratingHat;
		omega = 0;
		 err = 0;
		 miu = 0;
		 sigma1 = 0;
		sample_count = 0;
		 phi =0;
		 a = 1;
         D=0;
% 		 D = zeros(N,1);
% %         dWeight=zeros(N,1)+1/N ;
% dWeight=(ones(N,1)/N)';
sample_count = 0;

for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
    L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
err=abs(L_norm1-L_ex11);
miu =miu+ err;
sigma1=sigma1+ err.^2;
sample_count=sample_count+1;
end
%dWeight=1/sample_count;
miu = miu / sample_count;
sigma1 =sqrt(sigma1 / sample_count - miu.^2);
for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
 L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
    err=abs(L_norm1-L_ex11);
    if ((err - miu) > a * sigma1)
        phi=phi+dWeight(i);
    end
end
for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
 L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
    err=abs(L_norm1-L_ex11);
    if ((err - miu) > a * sigma1)
        dWeight(i)=dWeight(i)* phi;
    end
    D =D +dWeight(i);
end
for i = 1:length(q1_batch)%each i represent one measurement
dWeight(i)=dWeight(i)/D;
end
omega =log(1 / phi);
% a_d_alpha_theta0_norm=a_d_alpha_theta0_norm*omega;
% % a_d_alpha_theta0_norm1=zeros(24,1);
% % for i = 1:length(q1_batch)%each i represent one measurement
% %     q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
% %     a_d_alpha_theta0_norm1=a_d_alpha_theta0_norm1+a_d_alpha_theta0_norm*omega;
% % end
% omega2=[omega;a_d_alpha_theta0_norm];
omega2=omega;
KK2=a_d_alpha_theta0_norm;
%�����˲�ģ��
a_d_alpha_theta0_norm0=...
     [-0.00131345829047206
0.269309123878234
0.0697084056641824
-0.000241236235807545
0.000116652477496651
-0.00105085477730982
0.289314556685929
-0.000204682216714734
-0.000592916252102009
0.300838719683844
-0.000503401180187084
0.0724402741966926
-1.57128226401335
8.93140040880154e-05
-1.57013411337932
1.57016416346986
-1.57070357372679
0.000662807589513917
0.000550280107386789
-1.56900876020643
-0.000290536778815294
0.000391789810400590
0.000429419069679910
-6.95127760921776e-05];
%a_d_alpha_theta0_norm=rand(24,1);%[];%�����˵��������a d alpha theta0
a_d_alpha_theta0_norm=a_d_alpha_theta0_norm0;
% a_d_alpha_theta0_ex=a_d_alpha_theta0_norm.*(1+0.01*rands(24,1));
% %a_d_alpha_theta0_ex=a_d_alpha_theta0_norm0;
% q1_batch = pi/2*rands(30,1);
% q2_batch = pi/2*rands(30,1);
% q3_batch = pi/2*rands(30,1);
% q4_batch = pi/2*rands(30,1);
% q5_batch = pi/2*rands(30,1);
% q6_batch = pi/2*rands(30,1);
Data1 = xlsread('Data.xlsx',1,'D2:J112');
Data2 = xlsread('Data.xlsx',2,'D2:J22');
U=Data1(:,1:6)*pi/180;
MM1=Data1(:,7)/1000;
UU=Data2(:,1:6)*pi/180;
VV1=Data2(:,7)/1000;

q1_batch = U(:,1);
q2_batch = U(:,2);
q3_batch = U(:,3);
q4_batch = U(:,4);
q5_batch = U(:,5);
q6_batch = U(:,6);
N=length(q1_batch);
%------------------------------------------%------------------------------------------
%------------------------------------------%------------------------------------------
% Iter=6;
Iter=5;
MSE_store=zeros(0,1);
% K1=1e-7;
% K2=1e-7;
K1=1e-7;
K2=1e-7;
v=0.001*rands(1,1);
% P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
% KH1=0.0004;
%KH1=1e-5;
KH1=1e-4;
b=0.001*rands(24,1);


%double ratingHat;
omega = 0;
		 err = 0;
		 miu = 0;
		 sigma1 = 0;
		sample_count = 0;
		 phi =0;
		 a = 1;
         D=0;
% 		 D = zeros(N,1);
% %         dWeight=zeros(N,1)+1/N ;
% dWeight=(ones(N,1)/N)';
sample_count = 0;

for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
    L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
err=abs(L_norm1-L_ex11);
miu =miu+ err;
sigma1=sigma1+ err.^2;
sample_count=sample_count+1;
end
%dWeight=1/sample_count;
miu = miu / sample_count;
sigma1 =sqrt(sigma1 / sample_count - miu.^2);
for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
 L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
    err=abs(L_norm1-L_ex11);
    if ((err - miu) > a * sigma1)
        phi=phi+dWeight(i);
    end
end
for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
 L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
    err=abs(L_norm1-L_ex11);
    if ((err - miu) > a * sigma1)
        dWeight(i)=dWeight(i)* phi;
    end
    D =D +dWeight(i);
end
for i = 1:length(q1_batch)%each i represent one measurement
dWeight(i)=dWeight(i)/D;
end
omega =log(1 / phi);
% a_d_alpha_theta0_norm=a_d_alpha_theta0_norm*omega;
% % a_d_alpha_theta0_norm1=zeros(24,1);
% % for i = 1:length(q1_batch)%each i represent one measurement
% %     q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
% %     a_d_alpha_theta0_norm1=a_d_alpha_theta0_norm1+a_d_alpha_theta0_norm*omega;
% % end
% omega3=[omega;a_d_alpha_theta0_norm];
omega3=omega;
KK3=a_d_alpha_theta0_norm;

%�Ŵ��㷨ģ��4
a_d_alpha_theta0_norm0=...
     [-0.003544680574327
   0.269677857928149
   0.070076525442273
   0.000035954797466
  -0.000157631987001
  -0.000044124086936
   0.290095310375795
  -0.000180200150986
   0.000025291352522
   0.301972445219093
  -0.000004162924009
   0.072004648921874
  -1.570902323364732
   0.000014829836949
  -1.570734625007067
   1.571660441130738
  -1.571008405588589
  -0.000107833258836
   0.000249878611152
  -1.569168372626613
   0.008425424305972
  -0.002814444193507
   0.000466814076836
  -0.001790419098562];
%a_d_alpha_theta0_norm=rand(24,1);%[];%�����˵��������a d alpha theta0
a_d_alpha_theta0_norm=a_d_alpha_theta0_norm0;
% a_d_alpha_theta0_ex=a_d_alpha_theta0_norm.*(1+0.01*rands(24,1));
% %a_d_alpha_theta0_ex=a_d_alpha_theta0_norm0;
% q1_batch = pi/2*rands(30,1);
% q2_batch = pi/2*rands(30,1);
% q3_batch = pi/2*rands(30,1);
% q4_batch = pi/2*rands(30,1);
% q5_batch = pi/2*rands(30,1);
% q6_batch = pi/2*rands(30,1);
Data1 = xlsread('Data.xlsx',1,'D2:J112');
Data2 = xlsread('Data.xlsx',2,'D2:J22');
U=Data1(:,1:6)*pi/180;
MM1=Data1(:,7)/1000;
UU=Data2(:,1:6)*pi/180;
VV1=Data2(:,7)/1000;

q1_batch = U(:,1);
q2_batch = U(:,2);
q3_batch = U(:,3);
q4_batch = U(:,4);
q5_batch = U(:,5);
q6_batch = U(:,6);
N=length(q1_batch);
%------------------------------------------%------------------------------------------
%------------------------------------------%------------------------------------------
Iter=5;
MSE_store=zeros(0,1);
K1=1e-6;
v=0.00005*rands(1,1);
% P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
% KH1=0.0004;
KH1=1e-4;
b=0.00001*rands(24,1);


%double ratingHat;
omega = 0;
		 err = 0;
		 miu = 0;
		 sigma1 = 0;
		sample_count = 0;
		 phi =0;
		 a = 1;
         D=0;
% 		 D = zeros(N,1);
% %         dWeight=zeros(N,1)+1/N ;
% dWeight=(ones(N,1)/N)';
sample_count = 0;

for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
    L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
err=abs(L_norm1-L_ex11);
miu =miu+ err;
sigma1=sigma1+ err.^2;
sample_count=sample_count+1;
end
%dWeight=1/sample_count;
miu = miu / sample_count;
sigma1 =sqrt(sigma1 / sample_count - miu.^2);
for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
 L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
    err=abs(L_norm1-L_ex11);
    if ((err - miu) > a * sigma1)
        phi=phi+dWeight(i);
    end
end
for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
 L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
    err=abs(L_norm1-L_ex11);
    if ((err - miu) > a * sigma1)
        dWeight(i)=dWeight(i)* phi;
    end
    D =D +dWeight(i);
end
for i = 1:length(q1_batch)%each i represent one measurement
dWeight(i)=dWeight(i)/D;
end
omega =log(1 / phi);
% a_d_alpha_theta0_norm=a_d_alpha_theta0_norm*omega;
% % a_d_alpha_theta0_norm1=zeros(24,1);
% % for i = 1:length(q1_batch)%each i represent one measurement
% %     q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
% %     a_d_alpha_theta0_norm1=a_d_alpha_theta0_norm1+a_d_alpha_theta0_norm*omega;
% % end
% omega4=[omega;a_d_alpha_theta0_norm];
omega4=omega;
KK4=a_d_alpha_theta0_norm;
%SVMģ��5

a_d_alpha_theta0_norm0=...
     [0
   0.270000000000000
   0.070000000000000
                   0
                   0
                   0
   0.290000000000000
                   0
                   0
   0.302000000000000
                   0
   0.072000000000000
  -1.571000000000000
                   0
  -1.571000000000000
   1.571000000000000
  -1.571000000000000
                   0
   0.001952212683001
  -1.567951944176339
   0.002096967598019
   0.002167461535692
   0.001120594859269
   0.002064042464999];
%a_d_alpha_theta0_norm=rand(24,1);%[];%�����˵��������a d alpha theta0
a_d_alpha_theta0_norm=a_d_alpha_theta0_norm0;
% a_d_alpha_theta0_ex=a_d_alpha_theta0_norm.*(1+0.01*rands(24,1));
% %a_d_alpha_theta0_ex=a_d_alpha_theta0_norm0;
% q1_batch = pi/2*rands(30,1);
% q2_batch = pi/2*rands(30,1);
% q3_batch = pi/2*rands(30,1);
% q4_batch = pi/2*rands(30,1);
% q5_batch = pi/2*rands(30,1);
% q6_batch = pi/2*rands(30,1);
Data1 = xlsread('Data.xlsx',1,'D2:J112');
Data2 = xlsread('Data.xlsx',2,'D2:J22');
U=Data1(:,1:6)*pi/180;
MM1=Data1(:,7)/1000;
UU=Data2(:,1:6)*pi/180;
VV1=Data2(:,7)/1000;

q1_batch = U(:,1);
q2_batch = U(:,2);
q3_batch = U(:,3);
q4_batch = U(:,4);
q5_batch = U(:,5);
q6_batch = U(:,6);
N=length(q1_batch);
%------------------------------------------%------------------------------------------
%------------------------------------------%------------------------------------------
Iter=5;
MSE_store=zeros(0,1);
K1=1e-6;
v=0.001*rands(1,1);
% P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
% KH1=0.0004;
KH1=1e-4;
b=0.001*rands(24,1);


%double ratingHat;
omega = 0;
		 err = 0;
		 miu = 0;
		 sigma1 = 0;
		sample_count = 0;
		 phi =0;
		 a = 1;
         D=0;
% 		 D = zeros(N,1);
% %         dWeight=zeros(N,1)+1/N ;
% dWeight=(ones(N,1)/N)';
sample_count = 0;

for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
    L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
err=abs(L_norm1-L_ex11);
miu =miu+ err;
sigma1=sigma1+ err.^2;
sample_count=sample_count+1;
end
%dWeight=1/sample_count;
miu = miu / sample_count;
sigma1 =sqrt(sigma1 / sample_count - miu.^2);
for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
 L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
    err=abs(L_norm1-L_ex11);
    if ((err - miu) > a * sigma1)
        phi=phi+dWeight(i);
    end
end
for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
 L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
    err=abs(L_norm1-L_ex11);
    if ((err - miu) > a * sigma1)
        dWeight(i)=dWeight(i)* phi;
    end
    D =D +dWeight(i);
end
for i = 1:length(q1_batch)%each i represent one measurement
dWeight(i)=dWeight(i)/D;
end
omega =log(1 / phi);
% a_d_alpha_theta0_norm=a_d_alpha_theta0_norm*omega;
% % a_d_alpha_theta0_norm1=zeros(24,1);
% % for i = 1:length(q1_batch)%each i represent one measurement
% %     q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
% %     a_d_alpha_theta0_norm1=a_d_alpha_theta0_norm1+a_d_alpha_theta0_norm*omega;
% % end
% omega5=[omega;a_d_alpha_theta0_norm];
omega5=omega;
KK5=a_d_alpha_theta0_norm;

%EKF+PFģ��6
a_d_alpha_theta0_norm0=...
     [-0.001200702558141
   0.268921291312879
   0.069708405664182
  -0.000241236235808
   0.000116652477497
  -0.000936730700239
   0.288899476149239
  -0.000178275393127
  -0.000566527175238
   0.300963714562224
  -0.000371616667786
   0.072440274196693
  -1.571282629679591
   0.000101723193765
  -1.570123181937280
   1.570166907031870
  -1.570693705244220
   0.000662807589514
   0.000550280107387
  -1.569008760206430
  -0.000159375622921
   0.000401492854602
   0.000428108276514
  -0.000069441778954];
%a_d_alpha_theta0_norm=rand(24,1);%[];%�����˵��������a d alpha theta0
a_d_alpha_theta0_norm=a_d_alpha_theta0_norm0;
% a_d_alpha_theta0_ex=a_d_alpha_theta0_norm.*(1+0.01*rands(24,1));
% %a_d_alpha_theta0_ex=a_d_alpha_theta0_norm0;
% q1_batch = pi/2*rands(30,1);
% q2_batch = pi/2*rands(30,1);
% q3_batch = pi/2*rands(30,1);
% q4_batch = pi/2*rands(30,1);
% q5_batch = pi/2*rands(30,1);
% q6_batch = pi/2*rands(30,1);
Data1 = xlsread('Data.xlsx',1,'D2:J112');
Data2 = xlsread('Data.xlsx',2,'D2:J22');
U=Data1(:,1:6)*pi/180;
MM1=Data1(:,7)/1000;
UU=Data2(:,1:6)*pi/180;
VV1=Data2(:,7)/1000;

q1_batch = U(:,1);
q2_batch = U(:,2);
q3_batch = U(:,3);
q4_batch = U(:,4);
q5_batch = U(:,5);
q6_batch = U(:,6);
N=length(q1_batch);
%------------------------------------------%------------------------------------------
%------------------------------------------%------------------------------------------
Iter=5;
MSE_store=zeros(0,1);
K1=1e-6;
v=0.001*rands(1,1);
% P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
% KH1=0.0004;
KH1=1e-4;
% b=0.00001*rands(24,1);
b=1*rands(24,1);



%double ratingHat;
omega = 0;
		 err = 0;
		 miu = 0;
		 sigma1 = 0;
		sample_count = 0;
		 phi =0;
		 a = 1;
         D=0;
% 		 D = zeros(N,1);
% %         dWeight=zeros(N,1)+1/N ;
% dWeight=(ones(N,1)/N)';
sample_count = 0;

for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
    L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
err=abs(L_norm1-L_ex11);
miu =miu+ err;
sigma1=sigma1+ err.^2;
sample_count=sample_count+1;
end
%dWeight=1/sample_count;
miu = miu / sample_count;
sigma1 =sqrt(sigma1 / sample_count - miu.^2);
for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
 L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
    err=abs(L_norm1-L_ex11);
    if ((err - miu) > a * sigma1)
        phi=phi+dWeight(i);
    end
end
for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
 L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
    err=abs(L_norm1-L_ex11);
    if ((err - miu) > a * sigma1)
        dWeight(i)=dWeight(i)* phi;
    end
    D =D +dWeight(i);
end
for i = 1:length(q1_batch)%each i represent one measurement
dWeight(i)=dWeight(i)/D;
end
omega =log(1 / phi);
% a_d_alpha_theta0_norm=a_d_alpha_theta0_norm*omega;
% % a_d_alpha_theta0_norm1=zeros(24,1);
% % for i = 1:length(q1_batch)%each i represent one measurement
% %     q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
% %     a_d_alpha_theta0_norm1=a_d_alpha_theta0_norm1+a_d_alpha_theta0_norm*omega;
% % end
% omega6=[omega;a_d_alpha_theta0_norm];
omega6=omega;
KK6=a_d_alpha_theta0_norm;

%GA+LMģ��7

% a_d_alpha_theta0_norm0=...
%      [ -0.000005273028705
%    0.271012089434867
%    0.070013553985856
%   -0.010159872912413
%   -0.012068941478493
%    0.000472054157525
%    0.320525470394385
%    0.005075660538884
%    0.005326400927142
%    0.314315278068652
%   -0.010497057845351
%    0.088568126794052
%   -1.575352461701356
%   -0.003523369859490
%   -1.569245258616463
%    1.571743462531019
%   -1.571862758618184
%   -0.000107833258836
%    0.020610461488948
%   -1.560674762830302
%    0.009827953755857
%   -0.003674011795415
%    0.001161203091476
%   -0.001773608413825];
a_d_alpha_theta0_norm0=...
     [ -0.003073666106636
   0.269167867153142
   0.070115895920683
   0.000054711137007
  -0.000622248035073
  -0.000408589822607
   0.290319903678358
  -0.000211645790043
  -0.000006152727093
   0.301763240330856
  -0.000061781833037
   0.071948941958027
  -1.570982185868304
   0.000002132070292
  -1.570745609345939
   1.571667939879298
  -1.571012607206551
  -0.000107833258836
   0.000189598588891
  -1.569418600426781
   0.008432897168677
  -0.002820410836836
   0.000500211629761
  -0.001790301400879];
%a_d_alpha_theta0_norm=rand(24,1);%[];%�����˵��������a d alpha theta0
a_d_alpha_theta0_norm=a_d_alpha_theta0_norm0;
% a_d_alpha_theta0_ex=a_d_alpha_theta0_norm.*(1+0.01*rands(24,1));
% %a_d_alpha_theta0_ex=a_d_alpha_theta0_norm0;
% q1_batch = pi/2*rands(30,1);
% q2_batch = pi/2*rands(30,1);
% q3_batch = pi/2*rands(30,1);
% q4_batch = pi/2*rands(30,1);
% q5_batch = pi/2*rands(30,1);
% q6_batch = pi/2*rands(30,1);
Data1 = xlsread('Data.xlsx',1,'D2:J112');
Data2 = xlsread('Data.xlsx',2,'D2:J22');
U=Data1(:,1:6)*pi/180;
MM1=Data1(:,7)/1000;
UU=Data2(:,1:6)*pi/180;
VV1=Data2(:,7)/1000;

q1_batch = U(:,1);
q2_batch = U(:,2);
q3_batch = U(:,3);
q4_batch = U(:,4);
q5_batch = U(:,5);
q6_batch = U(:,6);
N=length(q1_batch);
%------------------------------------------%------------------------------------------
%------------------------------------------%------------------------------------------
Iter=5;
MSE_store=zeros(0,1);
K1=1e-6;
v=0.001*rands(1,1);
% P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
% KH1=0.0004;
KH1=1e-4;
% b=0.00001*rands(24,1);
b=1*rands(24,1);



%double ratingHat;
omega = 0;
		 err = 0;
		 miu = 0;
		 sigma1 = 0;
		sample_count = 0;
		 phi =0;
		 a = 1;
         D=0;
% 		 D = zeros(N,1);
% %         dWeight=zeros(N,1)+1/N ;
% dWeight=(ones(N,1)/N)';
sample_count = 0;

for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
    L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
err=abs(L_norm1-L_ex11);
miu =miu+ err;
sigma1=sigma1+ err.^2;
sample_count=sample_count+1;
end
%dWeight=1/sample_count;
miu = miu / sample_count;
sigma1 =sqrt(sigma1 / sample_count - miu.^2);
for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
 L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
    err=abs(L_norm1-L_ex11);
    if ((err - miu) > a * sigma1)
        phi=phi+dWeight(i);
    end
end
for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
 L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
    err=abs(L_norm1-L_ex11);
    if ((err - miu) > a * sigma1)
        dWeight(i)=dWeight(i)* phi;
    end
    D =D +dWeight(i);
end
for i = 1:length(q1_batch)%each i represent one measurement
dWeight(i)=dWeight(i)/D;
end
omega =log(1 / phi);
% a_d_alpha_theta0_norm=a_d_alpha_theta0_norm*omega;
% % a_d_alpha_theta0_norm1=zeros(24,1);
% % for i = 1:length(q1_batch)%each i represent one measurement
% %     q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
% %     a_d_alpha_theta0_norm1=a_d_alpha_theta0_norm1+a_d_alpha_theta0_norm*omega;
% % end
% omega6=[omega;a_d_alpha_theta0_norm];
omega7=omega;
KK7=a_d_alpha_theta0_norm;


%GA+SVMģ��8

a_d_alpha_theta0_norm0=...
     [-0.003544680574327
   0.269677857928149
   0.070076525442273
   0.000035954797466
  -0.000157631987001
  -0.000044124086936
   0.290095310375795
  -0.000180200150986
   0.000025291352522
   0.301972445219093
  -0.000004162924009
   0.072004648921874
  -1.570902323364732
   0.000014829836949
  -1.570734625007067
   1.571660441130738
  -1.571008405588589
  -0.000107833258836
   0.000092056253013
  -1.569388795153862
   0.008229134034377
  -0.002985748953305
   0.000368966710747
  -0.001977814523413];
%a_d_alpha_theta0_norm=rand(24,1);%[];%�����˵��������a d alpha theta0
a_d_alpha_theta0_norm=a_d_alpha_theta0_norm0;
% a_d_alpha_theta0_ex=a_d_alpha_theta0_norm.*(1+0.01*rands(24,1));
% %a_d_alpha_theta0_ex=a_d_alpha_theta0_norm0;
% q1_batch = pi/2*rands(30,1);
% q2_batch = pi/2*rands(30,1);
% q3_batch = pi/2*rands(30,1);
% q4_batch = pi/2*rands(30,1);
% q5_batch = pi/2*rands(30,1);
% q6_batch = pi/2*rands(30,1);
Data1 = xlsread('Data.xlsx',1,'D2:J112');
Data2 = xlsread('Data.xlsx',2,'D2:J22');
U=Data1(:,1:6)*pi/180;
MM1=Data1(:,7)/1000;
UU=Data2(:,1:6)*pi/180;
VV1=Data2(:,7)/1000;

q1_batch = U(:,1);
q2_batch = U(:,2);
q3_batch = U(:,3);
q4_batch = U(:,4);
q5_batch = U(:,5);
q6_batch = U(:,6);
N=length(q1_batch);
%------------------------------------------%------------------------------------------
%------------------------------------------%------------------------------------------
Iter=5;
MSE_store=zeros(0,1);
K1=1e-6;
v=0.001*rands(1,1);
% P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
P0=[ 0.24500 -0.45600 0.00665]';%�궨�㣬����Ч��
% KH1=0.0004;
KH1=1e-4;
% b=0.00001*rands(24,1);
b=1*rands(24,1);



%double ratingHat;
omega = 0;
		 err = 0;
		 miu = 0;
		 sigma1 = 0;
		sample_count = 0;
		 phi =0;
		 a = 1;
         D=0;
% 		 D = zeros(N,1);
% %         dWeight=zeros(N,1)+1/N ;
% dWeight=(ones(N,1)/N)';
sample_count = 0;

for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
    L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
err=abs(L_norm1-L_ex11);
miu =miu+ err;
sigma1=sigma1+ err.^2;
sample_count=sample_count+1;
end
%dWeight=1/sample_count;
miu = miu / sample_count;
sigma1 =sqrt(sigma1 / sample_count - miu.^2);
for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
 L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
    err=abs(L_norm1-L_ex11);
    if ((err - miu) > a * sigma1)
        phi=phi+dWeight(i);
    end
end
for i = 1:length(q1_batch)%each i represent one measurement
    q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
 L_ex11=MM1(i);
    L_norm1=my_forward(a_d_alpha_theta0_norm,q,P0);
    err=abs(L_norm1-L_ex11);
    if ((err - miu) > a * sigma1)
        dWeight(i)=dWeight(i)* phi;
    end
    D =D +dWeight(i);
end
for i = 1:length(q1_batch)%each i represent one measurement
dWeight(i)=dWeight(i)/D;
end
omega =log(1 / phi);
% a_d_alpha_theta0_norm=a_d_alpha_theta0_norm*omega;
% % a_d_alpha_theta0_norm1=zeros(24,1);
% % for i = 1:length(q1_batch)%each i represent one measurement
% %     q=[q1_batch(i);q2_batch(i);q3_batch(i);q4_batch(i);q5_batch(i);q6_batch(i)];
% %     a_d_alpha_theta0_norm1=a_d_alpha_theta0_norm1+a_d_alpha_theta0_norm*omega;
% % end
% omega6=[omega;a_d_alpha_theta0_norm];
omega8=omega;
KK8=a_d_alpha_theta0_norm;


omega22=[omega1;omega2;omega3;omega4;omega5;omega6;omega7;omega8;KK1;KK2;KK3;KK4;KK5;KK6;KK7;KK8];








